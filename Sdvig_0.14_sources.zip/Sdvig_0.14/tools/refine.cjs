const fs=require('node:fs'),C=require('../campaign-core.js'),{make,solve}=require('./generate.cjs');require('../campaign-levels.js');
const levels=SDVIG_LEVELS;
function replay(c,path){let s=C.initial(c);try{for(let i=0;i<path.length;i++){s=C.simulate(s,path[i],c);if(C.won(s,c))return {state:s,length:i+1};}}catch{}return null;}
let removed=0;
for(let i=0;i<levels.length;i++){
 let c=levels[i];
 if(c.lesson){let candidate=null;for(let attempt=0;attempt<150&&!candidate;attempt++){
 const n=make(c.id,attempt);const found=solve(n,5,n.focus==='tide'?7:6);if(!found)continue;
 if(n.focus==='pair'&&!found.solution.some(m=>m.axis===n.pair.axis&&[n.pair.a,n.pair.b].includes(m.index)))continue;
 if(n.focus==='compass'&&found.solution.length<2)continue;
 candidate={...n,solution:found.solution,proof:{expanded:found.expanded,steps:found.solution.length}};
 }if(!candidate)throw Error('Cannot simplify lesson '+c.id);c=levels[i]=candidate;
 }
 let solution=c.solution;
 // Delete redundant contiguous sections, re-simulating the whole candidate.
 // This is a witness reduction, never a claim of shortest-path optimality.
 for(let size=Math.floor(solution.length/2);size>=1;size--){
 for(let at=0;at+size<=solution.length;at++){
 const candidate=solution.slice(0,at).concat(solution.slice(at+size));const r=replay(c,candidate);
 if(r){removed+=solution.length-r.length;solution=candidate.slice(0,r.length);at=-1;}
 }
 }
 c.solution=solution;c.moves=solution.length+(c.lesson?5:c.id%25===0?2:c.id<151?4:3);
 const r=replay(c,solution);if(!r)throw Error('Invalid '+c.id);
 c.proof={...c.proof,steps:solution.length,beacons:c.beacons.length,minimumTurns:c.beacons.length,method:'verified witness, redundant sections removed; not a shortest-path proof',collected:r.state.progress};
 if(c.id%25===0)console.log(c.id,solution.length);
}
fs.writeFileSync(require('node:path').join(__dirname,'../campaign-levels.js'),'globalThis.SDVIG_LEVELS='+JSON.stringify(levels)+';\n');
console.log('Removed',removed,'redundant witness moves');
