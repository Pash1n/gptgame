const fs=require('node:fs'),path=require('node:path'),C=require('../campaign-core.js'),{make,solve}=require('./generate.cjs');require('../campaign-levels.js');let count=0;
for(let i=0;i<SDVIG_LEVELS.length;i++){
 let c=SDVIG_LEVELS[i];if(c.lesson)continue;
 const cap=[8,12,16,18,22,25,28,30,32,34][c.chapter];
 if(c.solution.length<=cap)continue;
 let replacement=null;
 for(let attempt=150;attempt<190&&!replacement;attempt++){
 const n=make(c.id,attempt),found=solve(n,5,cap);if(found)replacement={...n,solution:found.solution,proof:{steps:found.solution.length,expanded:found.expanded,minimumTurns:n.beacons.length,method:'verified constructive witness; not optimal',collected:found.state.progress}};
 }
 if(replacement){replacement.moves=replacement.solution.length+(c.id%25===0?2:c.id<151?4:3);SDVIG_LEVELS[i]=replacement;count++;console.log(c.id,c.solution.length,'->',replacement.solution.length);}
 else console.log('RETAIN',c.id,c.solution.length);
}
fs.writeFileSync(path.join(__dirname,'../campaign-levels.js'),'globalThis.SDVIG_LEVELS='+JSON.stringify(SDVIG_LEVELS)+';\n');console.log('Rebalanced',count);
