const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});const p=await b.newPage({viewport:{width:1440,height:1000}});const errors=[];p.on('pageerror',e=>errors.push(e.message));await p.goto((process.env.SDVIG_URL||'http://127.0.0.1:8014/')+'?test=1');await p.waitForFunction(()=>document.documentElement.dataset.ready==='true');
const result=await p.evaluate(()=>{
const results=[];
for(const id of [1,20,21,46,66,86,106,126,146,166,186,206,226,500]){
 sdvigTest.advance(3000);if(!sdvigTest.open(id))throw Error('Open '+id);sdvigTest.advance(3000);
 let data=sdvigTest.state(),s=data.config.modern?SdvigCampaign.initial(data.config):null;
 for(const move of data.config.solution){
 if(!sdvigTest.move(move))throw Error('Move refused '+id);
 if(s)s=SdvigCampaign.simulate(s,move,data.config);
 sdvigTest.advance(20000);const actual=sdvigTest.state();
 if(s){const cap=actual.capture,m=cap.modern;
 const expected=JSON.stringify([s.grid.map(r=>r.map(t=>[t.color,!!t.bomb])),s.pins,s.progress,s.terrain,s.rngState|0,s.locked,s.beacon,s.runes]);
 const got=JSON.stringify([actual.grid.map(r=>r.map(t=>[t.color,!!t.bomb])),m.pins,m.progress,cap.terrain,cap.rngState|0,cap.locked,m.extra.beacon,m.extra.runes]);
 if(expected!==got)throw Error('Parity failed '+id+' move '+JSON.stringify(move)+'\n'+expected+'\n'+got);}
 }
 data=sdvigTest.state();if(!data.finished||!document.querySelector('#result-title').textContent.includes('Получилось'))throw Error('Not won '+id);results.push({id,turns:data.capture.turns});
}return results;
});const report={timestamp:new Date().toISOString(),url:process.env.SDVIG_URL||'http://127.0.0.1:8014/',passed:result.length,result,errors};require('node:fs').writeFileSync('reports/build-smoke.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));await p.screenshot({path:'/workspace/artifacts/smoke-desktop.png'});await b.close();if(errors.length)process.exitCode=1;})().catch(e=>{console.error(e);process.exit(1)});
