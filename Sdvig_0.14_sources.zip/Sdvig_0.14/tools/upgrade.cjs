const fs=require('node:fs'),C=require('../campaign-core.js'),{solve}=require('./generate.cjs');require('../campaign-levels.js');
const old=SDVIG_LEVELS,changed=[];
for(let at=0;at<old.length;at++){
 const original=old[at],id=original.id;
 const mode=id>=51&&id<=60?'detour':id>=131&&id<=140?'portal':id>=151&&id<=160?'switch':id>=251&&id%9===0?'detour':id>=251&&id%9===3?'portal':id>=251&&id%9===6?'switch':null;
 if(!mode)continue;
 let found=null,c;
 for(let attempt=0;attempt<100&&!found;attempt++){
 const r=C.seeded(id*19777+attempt*100003+14),pick=n=>Math.floor(r()*n),lesson=[51,131,151].includes(id),early=id<251;
 c={...structuredClone(original),revision:14,lesson,focus:mode,detour:mode!=='portal',routeSide:-1,detourGoal:mode!=='portal'?1:0,portals:mode==='portal'||id>351&&id%27===6?[7,28]:null,portalGoal:mode==='portal'||id>351&&id%27===6?1:0,switcher:mode==='switch'?20:null,switchGoal:mode==='switch'?1:0};
 c.puzzleTitle=(lesson?'Открытие · ':'')+{detour:'Желейный объезд',portal:'Опаловые порталы',switch:'Развилка маршрута'}[mode];
 c.pins=c.detour?[14]:[];c.pinGoal=c.detour&&!early&&mode!=='switch';c.pair=null;c.tide=null;c.runes=[];c.compass=false;c.singleStep=false;c.lockRow=null;c.key=null;c.bombs=false;c.bombGoal=0;c.tideGoal=0;
 c.glass=Array(36).fill(0);if(!early&&id%2===0){c.glass[22]=1;c.glass[29]=1;}
 c.targets=early?[{color:lesson?0:pick(5),count:lesson?4:8}]:[{color:pick(3),count:12}];
 if(early)c.beacons=[];
 c.mechanics=[mode,...(c.portals&&mode!=='portal'?['portal']:[]),...(!early?['beacons']:[]),...(c.glass.some(Boolean)?['glass']:[])];
 c.seed=id*19777+attempt*100003+14;
 do{c.board=Array.from({length:6},()=>Array.from({length:6},()=>pick(5)));}while(C.match(c.board,c).ids.length);
 found=solve(c,attempt<5?4:8,lesson?6:early?12:34);
 }
 if(!found)throw Error('No solution '+id);
 c.solution=found.solution;c.moves=c.solution.length+(c.lesson?5:3);c.proof={steps:c.solution.length,expanded:found.expanded,minimumTurns:c.beacons.length,method:'shared-core verified constructive witness, not optimal',collected:found.state.progress};
 old[at]=c;changed.push({id,mode,steps:c.solution.length});console.log(id,mode,c.solution.length);
}
fs.writeFileSync('campaign-levels.js','globalThis.SDVIG_LEVELS='+JSON.stringify(old)+';\n');fs.writeFileSync('reports/upgraded-levels.json',JSON.stringify(changed,null,2));console.log('Changed',changed.length);
