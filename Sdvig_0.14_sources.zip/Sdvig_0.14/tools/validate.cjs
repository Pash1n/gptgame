const fs=require('node:fs'),assert=require('node:assert/strict'),C=require('../campaign-core.js');require('../campaign-levels.js');
const rows=[],began=Date.now();let totalMoves=0;
assert.equal(SDVIG_LEVELS.length,480);for(const [at,c] of SDVIG_LEVELS.entries()){
 assert.equal(c.id,at+21);assert.equal(C.match(c.board,c).ids.length,0,'Unstable initial board '+c.id);
 assert(c.moves>=c.solution.length);assert(!C.won(C.initial(c),c),'Initially won '+c.id);
 let s=C.initial(c),maxCascade=0,drifts=0;
 for(const move of c.solution){
 assert(C.actions(s,c).some(m=>JSON.stringify(m)===JSON.stringify(move)),'Illegal witness '+c.id);
 const old=s,result=C.simulate(s,move,c,true);s=result.state;
 assert(s.beacon-(old.beacon||0)<=1,'Multiple beacons per turn '+c.id);
 assert.equal(s.turn,old.turn+1);assert(s.grid.flat().every(t=>Number.isInteger(t.color)&&t.color>=0&&t.color<5));
 maxCascade=Math.max(maxCascade,result.events.filter(e=>e.type==='clear').length);drifts+=result.events.filter(e=>e.type==='drift').length;
 }
 assert(C.won(s,c),'Unsolved '+c.id);assert.equal(s.turn,c.solution.length);
 if(c.id>=251)assert(c.beacons.length>=5&&c.beacons.length<=9,'Late-level lower bound '+c.id);
 if(c.lesson)assert(c.solution.length<=7,'Long tutorial '+c.id);
 rows.push({id:c.id,passed:true,chapter:c.chapter+1,focus:c.focus,mechanics:c.mechanics,solutionMoves:c.solution.length,budget:c.moves,lowerBoundTurns:c.beacons.length,maxCascade,drifts,lesson:c.lesson});totalMoves+=s.turn;
}
const chapters=Array.from({length:10},(_,i)=>{const r=rows.filter(l=>l.chapter===i+1),sorted=r.map(l=>l.solutionMoves).sort((a,b)=>a-b);return {chapter:i+1,count:r.length,min:sorted[0],median:sorted[Math.floor(sorted.length/2)],max:sorted.at(-1),mean:Math.round(sorted.reduce((a,b)=>a+b,0)/r.length*10)/10};});
const report={timestamp:new Date().toISOString(),scope:'480 procedural levels, 21–500, deterministic core replay; authored levels verified separately in Chromium',passed:rows.length,failed:0,totalMoves,durationMs:Date.now()-began,lateLevelLowerBound:'251–500 require 5–9 ordered beacons. At most one beacon per turn; no one- or two-turn win is possible.',limitations:['Witness lengths are upper bounds, not shortest solutions.','Human enjoyment and perceived difficulty require playtesting.','No exhaustive search of all reachable game states.'],chapters,levels:rows};
fs.mkdirSync('reports',{recursive:true});fs.writeFileSync('reports/levels-core.json',JSON.stringify(report,null,2));console.log(JSON.stringify({...report,levels:undefined},null,2));
