# New map artwork, 0.14

Generated specifically for this version using the image-generation tool. Original transparent PNG: `map-atlas.png`, 1536×1024. Extracted into six 512×512 WebP sprites in `assets/map-*.webp`.

Art direction: premium friendly cartoon jelly-forest adventure, turquoise and mint with warm gold and peach, soft painted volume, three-quarter perspective, readable silhouettes, isolated transparent sprites. Atlas layout (3 columns × 2 rows): grassy island, glowing crystal cluster, mushroom cottage; turquoise treasure chest, magical portal arch, wooden signpost. No text or numbers painted into assets; level numbers and state are rendered separately for readability and accessibility.
