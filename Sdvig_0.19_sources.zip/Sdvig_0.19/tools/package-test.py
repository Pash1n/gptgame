"""Reproduce the single-file test release, runtime ZIP and source ZIP."""
from pathlib import Path
import subprocess,sys,zipfile,shutil,hashlib
root=Path(__file__).resolve().parent.parent
out=Path('/workspace/artifacts');out.mkdir(parents=True,exist_ok=True)
subprocess.run([sys.executable,str(root/'tools/standalone.py')],cwd=root,check=True)
subprocess.run([sys.executable,str(root/'tools/build.py')],cwd=root,check=True)
with zipfile.ZipFile(out/'Sdvig_0.19_TEST_ALL_500.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 z.write(out/'Sdvig_0.19_TEST_ALL_500.html','Sdvig_TEST_ALL_500.html')
 z.writestr('START_RU.txt','Распакуйте архив и откройте Sdvig_TEST_ALL_500.html. Все 500 уровней доступны. 51 — одиночный лёд; 52 — обход снизу; 53 — две льдинки; 54 — несколько обходов. Введите номер на карте и нажмите Открыть. Незавершённые старые уровни с изменёнными правилами начинаются заново, заработанные звёзды сохраняются.')
 z.write(root/'vendor/THREE-LICENSE.txt','THREE-LICENSE.txt')
shutil.copy(root/'reports/REPORT_RU.md',out/'Sdvig_0.19_REPORT_RU.md')
files=sorted(f for f in out.glob('Sdvig_0.19*') if f.name!='Sdvig_0.19_SHA256SUMS.txt')
for f in files:
 assert f.stat().st_size<100_000_000
 if f.suffix=='.zip':
  with zipfile.ZipFile(f) as z:assert z.testzip() is None
 print(f.name,f.stat().st_size)
(out/'Sdvig_0.19_SHA256SUMS.txt').write_text(''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.name+'\n' for f in files))
