/* A streamed, real WebGL world. No external assets or network are needed. */
(function(){'use strict';
const T=globalThis.THREE;
const palettes=[{sky:0x070b24,land:0x111c46,edge:0x151833,road:0x80e7ff,leaf:0x5577b8,crystal:0x75edff},{sky:0x100b2b,land:0x22153e,edge:0x22142f,road:0xc4a7ff,leaf:0x8066b4,crystal:0xcda6ff},{sky:0x120c25,land:0x271534,edge:0x2b142a,road:0xffc79c,leaf:0xa16ca3,crystal:0xffb9d7}];
const center=t=>Math.sin(t*.027)*7+Math.sin(t*.009)*3;
const height=t=>Math.sin(t*.012)*.6;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
class WorldMap{
 constructor(host,options){
 this.host=host;this.options=options;this.position=0;this.target=0;this.velocity=0;this.selected=1;this.chunks=new Map();this.buttons=new Map();this.materials=new Map();this.running=false;this.last=0;this.drag=null;this.suppressUntil=0;this.reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
 this.scene=new T.Scene();this.scene.fog=new T.Fog(palettes[0].sky,85,185);this.camera=new T.PerspectiveCamera(48,1,.2,230);
 this.renderer=new T.WebGLRenderer({antialias:true,alpha:true,powerPreference:'low-power'});this.renderer.setPixelRatio(Math.min(devicePixelRatio||1,1.6));this.renderer.setClearColor(0,0);this.renderer.outputColorSpace=T.SRGBColorSpace;this.renderer.setAnimationLoop(null);
 this.canvas=this.renderer.domElement;this.canvas.id='world-canvas';this.canvas.setAttribute('aria-label','Объёмная карта: потяните вверх или вниз, используйте колесо или стрелки.');this.canvas.tabIndex=0;
 this.labels=document.createElement('div');this.labels.id='world-labels';this.instructions=document.createElement('div');this.instructions.className='world-instructions';this.instructions.textContent='Полёт сквозь звёзды · потяни / ↑ ↓';
 this.nebula=document.createElement('div');this.nebula.className='space-nebula';this.nebula.setAttribute('aria-hidden','true');host.append(this.nebula,this.canvas,this.labels,this.instructions);
 this.scene.add(new T.HemisphereLight(0xffffff,0x22234d,1.1));const sun=new T.DirectionalLight(0xcdd5ff,2);sun.position.set(-25,45,30);this.scene.add(sun);const fill=new T.DirectionalLight(0xc2a5ff,1.3);fill.position.set(20,10,-20);this.scene.add(fill);
 this.geometries={ball:new T.SphereGeometry(1,12,8),cone:new T.ConeGeometry(1,1,7),cylinder:new T.CylinderGeometry(1,1,1,20),rock:new T.IcosahedronGeometry(1,0),crystal:new T.OctahedronGeometry(1,0),ring:new T.TorusGeometry(2.3,.16,6,32),cube:new T.BoxGeometry(1,1,1)};
 this.spaceMaterials=new Map();this.spaceTextures=[];this.pendingArt=6;const asset=name=>typeof globalThis.SDVIG_ASSET==='function'?globalThis.SDVIG_ASSET('assets/space-'+name+'.webp'):'assets/space-'+name+'.webp';
 for(const name of ['ocean','ringed','lava','meteors','comet','moon']){const texture=new T.TextureLoader().load(asset(name),()=>{this.pendingArt--;this.canvas.dataset.artReady=String(this.pendingArt===0);},undefined,()=>{this.canvas.dataset.artError=name;console.error('Space sprite failed:',name)});texture.colorSpace=T.SRGBColorSpace;this.spaceTextures.push(texture);this.spaceMaterials.set(name,new T.SpriteMaterial({map:texture,transparent:true,depthWrite:false,toneMapped:false,fog:false}));}
 this.createStarfield();
 this.ring=new T.Mesh(this.geometries.ring,this.mat(0xffe6a0));this.ring.rotation.x=-Math.PI/2;this.scene.add(this.ring);
 const portrait=document.querySelector('.result-jelly')?.src;if(portrait){this.heroTexture=new T.TextureLoader().load(portrait);this.heroTexture.colorSpace=T.SRGBColorSpace;this.hero=new T.Sprite(new T.SpriteMaterial({map:this.heroTexture,transparent:true,depthTest:true}));this.hero.scale.set(2.8,2.8,1);this.scene.add(this.hero);}
 this.bind();this.resizeObserver=new ResizeObserver(()=>this.resize());this.resizeObserver.observe(host);this.resize();
 this.contextLost=e=>{e.preventDefault();this.options.onError?.('Контекст 3D потерян. Закройте и снова откройте карту.');this.stop();};this.canvas.addEventListener('webglcontextlost',this.contextLost);
 }
 mat(color){if(!this.materials.has(color))this.materials.set(color,new T.MeshStandardMaterial({color,roughness:.45,metalness:.3,emissive:color,emissiveIntensity:.12,flatShading:false}));return this.materials.get(color);}
 add(group,type,color,x,y,z,sx=1,sy=sx,sz=sx){const m=new T.Mesh(this.geometries[type],this.mat(color));m.position.set(x,y,z);m.scale.set(sx,sy,sz);group.add(m);return m;}
 createStarfield(){
 const canvas=document.createElement('canvas');canvas.width=32;canvas.height=32;const ctx=canvas.getContext('2d'),gradient=ctx.createRadialGradient(16,16,0,16,16,16);gradient.addColorStop(0,'#fff');gradient.addColorStop(.12,'#fff');gradient.addColorStop(.35,'#ffffff88');gradient.addColorStop(1,'#ffffff00');ctx.fillStyle=gradient;ctx.fillRect(0,0,32,32);this.starTexture=new T.CanvasTexture(canvas);this.starTexture.colorSpace=T.SRGBColorSpace;
 this.warpGeometry=new T.BufferGeometry();this.warpPositions=new Float32Array(80*6);this.warpGeometry.setAttribute('position',new T.BufferAttribute(this.warpPositions,3));this.warpMaterial=new T.LineBasicMaterial({color:0xaedbff,transparent:true,opacity:0,depthWrite:false,blending:T.AdditiveBlending});this.warp=new T.LineSegments(this.warpGeometry,this.warpMaterial);this.warp.frustumCulled=false;this.scene.add(this.warp);
 this.stars=[];let seed=1616;const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)|0;return(seed>>>0)/4294967296};
 for(let layer=0;layer<3;layer++){const count=[600,440,220][layer],positions=new Float32Array(count*3),colors=new Float32Array(count*3),base=[];for(let i=0;i<count;i++)base.push({x:(random()-.5)*180,y:(random()-.35)*95,depth:random()*240,phase:random()*6.3});const geo=new T.BufferGeometry();geo.setAttribute('position',new T.BufferAttribute(positions,3));geo.setAttribute('color',new T.BufferAttribute(colors,3));const material=new T.PointsMaterial({size:[.18,.25,.4][layer],map:this.starTexture,transparent:true,depthWrite:false,blending:T.AdditiveBlending,vertexColors:true,toneMapped:false});const points=new T.Points(geo,material);points.frustumCulled=false;this.scene.add(points);this.stars.push({base,positions,colors,geo,material,points,speed:[.18,.5,1][layer],tint:new T.Color([0xbacfff,0x96e8ff,0xffd2f4][layer])});}
 }
 spaceSprite(group,name,x,y,z,size,phase=0){const sprite=new T.Sprite(this.spaceMaterials.get(name));sprite.position.set(x,y,z);sprite.scale.set(size,size,1);group.add(sprite);if(!group.userData.sprites)group.userData.sprites=[];group.userData.sprites.push({sprite,y,phase});return sprite;}
 ribbon(i,p){const positions=[],colors=[],start=(i-1)*12-6,segments=10,bright=new T.Color(p.road),dark=new T.Color(0x000000);
 const vertex=(x,y,z,color)=>{positions.push(x,y,z);colors.push(color.r,color.g,color.b);};
 for(let k=0;k<segments;k++){const a=start+k*12/segments,b=start+(k+1)*12/segments,xa=center(a),xb=center(b),ya=height(a)-.55,yb=height(b)-.55,w=3.2;for(const side of [-1,1]){vertex(xa+side*w,ya,-a,dark);vertex(xa,ya,-a,bright);vertex(xb,yb,-b,bright);vertex(xa+side*w,ya,-a,dark);vertex(xb,yb,-b,bright);vertex(xb+side*w,yb,-b,dark);}}
 const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(positions,3));geo.setAttribute('color',new T.Float32BufferAttribute(colors,3));geo.computeVertexNormals();const material=new T.MeshBasicMaterial({vertexColors:true,transparent:true,opacity:.22,depthWrite:false,side:T.DoubleSide,blending:T.AdditiveBlending,toneMapped:false});return new T.Mesh(geo,material);}
 bake(group){group.updateMatrixWorld(true);const bins=new Map(),terrain=group.userData.terrain;group.traverse(obj=>{if(!obj.isMesh||obj===terrain)return;const key=obj.material.uuid;if(!bins.has(key))bins.set(key,{material:obj.material,positions:[],normals:[]});const bin=bins.get(key),geo=obj.geometry.index?obj.geometry.toNonIndexed():obj.geometry.clone();geo.applyMatrix4(obj.matrixWorld);bin.positions.push(geo.attributes.position.array.slice());bin.normals.push(geo.attributes.normal.array.slice());geo.dispose();});
 for(const child of [...group.children])if(child!==terrain)group.remove(child);group.userData.baked=[];
 for(const bin of bins.values()){const concatenate=arrays=>{const result=new Float32Array(arrays.reduce((a,b)=>a+b.length,0));let offset=0;for(const array of arrays){result.set(array,offset);offset+=array.length;}return result;};const geo=new T.BufferGeometry();geo.setAttribute('position',new T.BufferAttribute(concatenate(bin.positions),3));geo.setAttribute('normal',new T.BufferAttribute(concatenate(bin.normals),3));group.add(new T.Mesh(geo,bin.material));group.userData.baked.push(geo);}
 }
 chunk(i){const index=i-1,t=index*12,chapter=Math.floor(index/50),p=palettes[chapter%3],g=new T.Group();g.userData.id=i;
 const terrain=this.ribbon(i,p);g.add(terrain);g.userData.terrain=terrain;
 // Floating orbital beacons along a faint stardust stream: no land or forest.
 for(let k=0;k<4;k++){const d=t-4.5+k*3;this.add(g,'ball',p.road,center(d),height(d)-.15,-d,.095,.095,.095);}
 const x=center(t),y=height(t),done=!!this.options.completed?.[i],locked=i>this.options.unlocked;
 this.add(g,'rock',0x252343,x,y-.05,-t,2,.5,1.8);
 this.add(g,'ball',done?0x9d6f43:locked?0x34334f:0x183e68,x,y+1.05,-t,1.75,.98,1.75);
 const orbit=this.add(g,'ring',done?0xffd99a:locked?0x676583:p.road,x,y+.7,-t,.85,.85,.85);orbit.rotation.x=-Math.PI/2;
 for(let k=0;k<2;k++){const rock=this.add(g,'rock',0x514563,x+(k?-1:1)*(4+i%3),y-1.3+k*.7,-t+2+k, .5+k*.25,.4+k*.15,.5+k*.2);rock.rotation.set(i*.3,k*.6,i*.15);}
 this.bake(g);
 const hash=(Math.sin(i*19.19)*43758.54)%1,side=hash>0?1:-1,kind=['ocean','ringed','moon','lava'][(i*5+Math.floor(i/7))%4];
 if(i%3!==1){const size=i%3===0?10.5+(i%3)*.9:7.5+(i%2)*.8;this.spaceSprite(g,kind,x+side*(10.5+(i%3)*1.1),y+2.5+(i%4)*.6,-t-1,size,i*.71);}
 else this.spaceSprite(g,'meteors',x+side*10,y+.8,-t+1,5.8,i);
 if(i%5===0)this.spaceSprite(g,'meteors',x-side*11,y-1.5,-t+3,4.5,i);
 if(i%11===0)this.spaceSprite(g,'comet',x-side*15,y+8,-t-7,13,i*.3);
 this.scene.add(g);this.chunks.set(i,g);
 const button=document.createElement('button');button.className='world-level'+(locked?' locked':'')+(done?' done':'');button.dataset.level=i;button.setAttribute('aria-label','Уровень '+i+(locked?' закрыт':done?' пройден':''));button.innerHTML='<b>'+i+'</b>'+(done?'<small>'+'★'.repeat(this.options.completed[i])+'</small>':'');button.onclick=()=>{if(performance.now()<this.suppressUntil)return;this.select(i);};button.onkeydown=e=>{if(e.key===' '||e.key==='Enter'){e.stopPropagation();}};this.labels.append(button);this.buttons.set(i,button);
 }
 remove(i){const g=this.chunks.get(i);this.scene.remove(g);for(const geo of g.userData.baked||[])geo.dispose();g.userData.terrain.geometry.dispose();g.userData.terrain.material.dispose();this.chunks.delete(i);this.buttons.get(i)?.remove();this.buttons.delete(i);}
 updateChunks(){const near=Math.floor(this.position/12)+1,min=Math.max(1,near-4),max=Math.min(500,near+17);for(const i of this.chunks.keys())if(i<min||i>max)this.remove(i);for(let i=min;i<=max;i++)if(!this.chunks.has(i))this.chunk(i);}
 setOptions(options){this.options={...this.options,...options};for(const i of [...this.chunks.keys()])this.remove(i);}
 select(i,immediate=false){this.selected=i;this.options.onSelect(i);this.focus(i,immediate);}
 focus(i,immediate=false){i=clamp(i,1,500);this.target=(i-1)*12;this.velocity=0;if(immediate||this.reduced)this.position=this.target;this.selected=i;this.start();}
 moveBy(d){this.target=clamp(this.target+d,0,499*12);this.velocity=0;this.start();}
 resize(){const w=this.host.clientWidth,h=this.host.clientHeight;if(!w||!h||w===this.width&&h===this.height)return;this.width=w;this.height=h;this.renderer.setSize(w,h,false);this.camera.aspect=w/h;this.camera.fov=w<h?56:38;this.camera.updateProjectionMatrix();}
 bind(){const host=this.host;
 host.addEventListener('pointerdown',e=>{if(e.button>0)return;this.drag={id:e.pointerId,start:e.clientY,last:e.clientY,time:performance.now(),moved:0};if(!e.target.closest('.world-level'))host.setPointerCapture(e.pointerId);this.velocity=0;this.canvas.focus({preventScroll:true});});
 host.addEventListener('pointermove',e=>{if(!this.drag||e.pointerId!==this.drag.id)return;const d=this.drag,now=performance.now(),dy=e.clientY-d.last,dt=Math.max(8,now-d.time);d.moved=Math.max(d.moved,Math.abs(e.clientY-d.start));const units=dy*.075;this.target=clamp(this.target+units,0,499*12);this.velocity=clamp(units/dt*1000,-90,90);d.last=e.clientY;d.time=now;if(d.moved>7){this.suppressUntil=now+300;if(!host.hasPointerCapture(e.pointerId))host.setPointerCapture(e.pointerId);}});
 const end=(e,cancel)=>{if(!this.drag)return;if(!cancel&&this.drag.moved>7&&!this.reduced)this.target=clamp(this.target+this.velocity*.18,0,499*12);this.velocity=0;this.drag=null;};host.addEventListener('pointerup',e=>end(e,false));host.addEventListener('pointercancel',e=>end(e,true));host.addEventListener('lostpointercapture',e=>end(e,true));
 host.addEventListener('wheel',e=>{e.preventDefault();const d=e.deltaY*(e.deltaMode===1?16:1);this.moveBy(clamp(d*.055,-24,24));},{passive:false});
 this.canvas.addEventListener('keydown',e=>{const d={ArrowUp:12,ArrowDown:-12,PageUp:60,PageDown:-60};if(e.key in d){e.preventDefault();this.moveBy(d[e.key]);}else if(e.key==='Home'){e.preventDefault();this.select(1,true);}else if(e.key==='End'){e.preventDefault();this.select(this.options.unlocked,true);}});
 }
 start(){if(this.running)return;this.running=true;this.last=performance.now();this.raf=requestAnimationFrame(t=>this.frame(t));}
 stop(){this.running=false;cancelAnimationFrame(this.raf);this.drag=null;}
 frame(now){if(!this.running)return;if(!this.host.closest('dialog')?.open){this.stop();return;}const dt=Math.min(.05,(now-this.last)/1000);this.last=now;this.resize();this.position+=this.reduced?this.target-this.position:clamp((this.target-this.position)*(1-Math.exp(-dt*7)),-18,18);if(Math.abs(this.position-this.target)<.002)this.position=this.target;this.updateChunks();
 const t=this.position,cx=center(t),chapter=Math.floor((Math.floor(t/12))/50),palette=palettes[chapter%3];this.scene.fog.color.lerp(new T.Color(palette.sky),1-Math.exp(-dt*2.5));this.host.style.setProperty('--sky','#'+this.scene.fog.color.getHexString());
 const sway=this.reduced?0:Math.sin(now*.00065)*.12;this.camera.position.set(cx*.72+sway,17+height(t),-t+22);this.camera.lookAt(center(t+20)*.7,height(t+20)+.7,-t-20);this.camera.updateMatrixWorld();
 const flight=clamp(Math.abs(this.target-this.position),0,16);this.warpMaterial.opacity=this.reduced?0:flight*.025;for(let i=0;i<80;i++){const depth=((i*17.13-t)%85+85)%85+12,x=cx*.2+Math.sin(i*23.7)*25,y=17+Math.cos(i*11.3)*22,z=-t+14-depth;this.warpPositions.set([x,y,z,x,y,z+flight*.12],i*6);}this.warpGeometry.attributes.position.needsUpdate=true;
 this.nebula.style.transform=`translate(${Math.sin(t*.001)*3}%,${Math.sin(t*.0007)*3}%) scale(1.05)`;
 for(const field of this.stars){for(let i=0;i<field.base.length;i++){const star=field.base[i],depth=((star.depth-t*field.speed)%240+240)%240;field.positions[i*3]=star.x+cx*.2;field.positions[i*3+1]=star.y;field.positions[i*3+2]=-t+14-depth;const brightness=(this.reduced ? .8 : .68+.22*Math.sin(now*.001+star.phase))*clamp(depth/10,0,1);field.colors[i*3]=field.tint.r*brightness;field.colors[i*3+1]=field.tint.g*brightness;field.colors[i*3+2]=field.tint.b*brightness;}field.geo.attributes.position.needsUpdate=true;field.geo.attributes.color.needsUpdate=true;}
 for(const group of this.chunks.values())for(const item of group.userData.sprites||[])item.sprite.position.y=item.y+(this.reduced?0:Math.sin(now*.0006+item.phase)*.15);
 const st=(this.selected-1)*12;this.ring.position.set(center(st),height(st)+2.35+(this.reduced?0:Math.sin(now*.003)*.08),-st);this.ring.scale.setScalar(1+(this.reduced?0:Math.sin(now*.002)*.05));
 if(this.hero){this.hero.position.set(center(st),height(st)+4.25+(this.reduced?0:Math.sin(now*.002)*.13),-st);}
 this.renderer.render(this.scene,this.camera);const v=new T.Vector3();
 for(const [i,button] of this.buttons){const d=(i-1)*12-t;v.set(center((i-1)*12),height((i-1)*12)+1.5,-(i-1)*12);v.project(this.camera);const visible=v.z>-1&&v.z<1&&Math.abs(v.x)<1.2&&Math.abs(v.y)<1.15&&d>-10&&d<104;button.hidden=!visible;if(!visible)continue;const scale=clamp(42/(d+39),.42,1.2);button.style.left=(v.x*.5+.5)*this.width+'px';button.style.top=(-v.y*.5+.5)*this.height+'px';button.style.transform=`translate(-50%,-50%) scale(${scale})`;button.classList.toggle('selected',i===this.selected);button.setAttribute('aria-pressed',String(i===this.selected));}
 const current=clamp(Math.floor(t/12)+1,1,500);this.canvas.dataset.position=this.position.toFixed(3);this.canvas.dataset.nearest=String(current);this.canvas.dataset.visibleChunks=String(this.chunks.size);this.canvas.dataset.webgl='true';this.canvas.dataset.theme='space';this.canvas.dataset.stars='1260';this.canvas.dataset.triangles=String(this.renderer.info.render.triangles);if(this.chapter!==chapter){this.chapter=chapter;this.options.onChapter?.(chapter);}
 this.raf=requestAnimationFrame(n=>this.frame(n));
 }
 dispose(){this.stop();this.resizeObserver.disconnect();for(const i of [...this.chunks.keys()])this.remove(i);for(const g of Object.values(this.geometries))g.dispose();for(const m of this.materials.values())m.dispose();this.heroTexture?.dispose();this.hero?.material.dispose();for(const field of this.stars){field.geo.dispose();field.material.dispose();}this.starTexture.dispose();this.warpGeometry.dispose();this.warpMaterial.dispose();for(const texture of this.spaceTextures)texture.dispose();for(const material of this.spaceMaterials.values())material.dispose();this.nebula.remove();this.renderer.dispose();this.canvas.remove();this.labels.remove();this.instructions.remove();}
}
globalThis.SdvigWorldMap=WorldMap;
})();
