(()=>{
'use strict';
const N=6;
const C=globalThis.SdvigCampaign;
function squares(grid){const groups=[],cells=new Set();for(let r=0;r<N-1;r++)for(let c=0;c<N-1;c++){const color=grid[r][c]?.color;if(color!==undefined&&grid[r][c+1]?.color===color&&grid[r+1][c]?.color===color&&grid[r+1][c+1]?.color===color){const ids=[r*N+c,r*N+c+1,(r+1)*N+c,(r+1)*N+c+1];groups.push({r,c,color});ids.forEach(i=>cells.add(i))}}return{groups,ids:[...cells]}}
function shifted(grid,axis,index,n){const result=grid.map(row=>row.slice());for(let k=0;k<N;k++){const to=((k+n)%N+N)%N;if(axis==='x')result[index][to]=grid[index][k];else result[to][index]=grid[k][index]}return result}
function findMove(grid){for(const n of [1,-1,2,-2,3])for(const axis of ['x','y'])for(let index=0;index<N;index++){const next=shifted(grid,axis,index,n);if(squares(next).ids.length)return{axis,index,n}}return null}

const clamp01=x=>Math.max(0,Math.min(1,x));
const easeOut=x=>1-(1-clamp01(x))**3;
const POP_DURATION=270,POP_BURST=218;
function settle(from,to,elapsed,duration=190){return from+(to-from)*easeOut(elapsed/duration)}
function fallPose(from,elapsed,duration=340){const p=clamp01(elapsed/duration);if(p<.79){const q=p/.79,travel=q*q*(3-2*q);return{y:from*(1-travel),sx:1-.025*Math.sin(Math.PI*q),sy:1+.05*Math.sin(Math.PI*q)}}const q=(p-.79)/.21,wave=Math.sin(Math.PI*q);return{y:-.045*wave*(1-q),sx:1+.075*wave,sy:1-.085*wave}}
function popPose(elapsed){const p=clamp01(elapsed/POP_DURATION);if(p<.36){const a=Math.sin(p/.36*Math.PI/2);return{scale:1+.06*a,sx:1+.055*a,sy:1-.075*a,pull:.08*a,alpha:1}}const q=clamp01((p-.36)/.64),v=q*q*(3-2*q);return{scale:1.06*(1-v),sx:1.055-.055*v,sy:.925+.075*v,pull:.08+.66*v,alpha:1-clamp01((q-.64)/.36)}}

const SPACE_BACKGROUND='assets/space-galaxy.webp';
const WORLDS=[{key:'forest',name:'Звёздный океан',image:SPACE_BACKGROUND,accent:'#9af5db'},{key:'lagoon',name:'Перламутровая туманность',image:SPACE_BACKGROUND,accent:'#dfc1ff'},{key:'islands',name:'Янтарная галактика',image:SPACE_BACKGROUND,accent:'#ffe0aa'}];
function worldForChapter(chapter){return WORLDS[((chapter%3)+3)%3]}
function chapterForLevel(id){return Math.floor((Math.min(500,Math.max(1,id))-1)/50)}
const ROAD_WIDTH=360,ROAD_GAP=124,ROAD_HEIGHT=50*ROAD_GAP+90;
function roadPoint(id,chapter=chapterForLevel(id)){const local=Math.min(49,Math.max(0,id-1-chapter*50));return{x:180+Math.sin(local*1.03)*99,y:ROAD_HEIGHT-105-local*ROAD_GAP}}
function roadSegment(a,b){return`M ${a.x} ${a.y} C ${a.x} ${a.y-52}, ${b.x} ${b.y+52}, ${b.x} ${b.y}`}
function roadPath(chapter){let result='';for(let i=0;i<49;i++){const a=roadPoint(chapter*50+i+1,chapter),b=roadPoint(chapter*50+i+2,chapter);result+=roadSegment(a,b)+' '}return result.trim()}
function validRoadMove(move,unlocked){return !!move&&Number.isInteger(move.from)&&Number.isInteger(move.to)&&move.from>=1&&move.to===move.from+1&&move.to<=Math.min(500,unlocked)}
function advanceRoad(progress,wonLevel){const unlocked=Math.min(500,Math.max(progress.unlocked,wonLevel+1));return{unlocked,move:wonLevel>=progress.unlocked&&wonLevel<500?{from:wonLevel,to:wonLevel+1}:null}}

const SHAPES={tee:{name:'Буква Т',cells:[[0,0],[0,1],[0,2],[1,1],[2,1]]},square:{name:'Квадрат',cells:[[0,0],[0,1],[1,0],[1,1]]},line:{name:'Линия',cells:[[0,0],[0,1],[0,2],[0,3]]},corner:{name:'Уголок',cells:[[0,0],[1,0],[2,0],[2,1],[2,2]]}};
const COLOR_NAMES=['Розовый','Голубой','Жёлтый','Фиолетовый','Зелёный'];
function rotations(shape){const result=[],seen=new Set();let cells=SHAPES[shape].cells;for(let k=0;k<4;k++){const mr=Math.min(...cells.map(p=>p[0])),mc=Math.min(...cells.map(p=>p[1]));const normalized=cells.map(([r,c])=>[r-mr,c-mc]).sort((a,b)=>a[0]-b[0]||a[1]-b[1]),key=JSON.stringify(normalized);if(!seen.has(key)){seen.add(key);result.push(normalized)}cells=cells.map(([r,c])=>[c,-r])}return result}
const patterns=Object.fromEntries(Object.keys(SHAPES).map(s=>[s,rotations(s)]));
const value=t=>typeof t==='number'?t:t?.color;
function figureMatch(grid,objective){
 if(!objective)return{groups:[],ids:[]};const candidates=[],seen=new Set();
 for(const cells of patterns[objective.shape]){const height=Math.max(...cells.map(p=>p[0]))+1,width=Math.max(...cells.map(p=>p[1]))+1;
 for(let r=0;r<=N-height;r++)for(let c=0;c<=N-width;c++){
 if(objective.anchor&&(r!==objective.anchor[0]||c!==objective.anchor[1]))continue;
 const ids=cells.map(([dr,dc])=>(r+dr)*N+c+dc),color=value(grid[Math.floor(ids[0]/N)][ids[0]%N]);if(color===undefined||(objective.color!==undefined&&objective.color!==null&&color!==objective.color))continue;
 if(!ids.every(i=>value(grid[Math.floor(i/N)][i%N])===color))continue;
 const key=ids.join(',');if(seen.has(key))continue;seen.add(key);candidates.push({r,c,color,ids,shape:objective.shape});
 }}
 // Count independent figures: overlapping 2×2 squares or line segments are one collection.
 const used=new Set(),groups=[];for(const g of candidates){if(g.ids.some(i=>used.has(i)))continue;groups.push(g);g.ids.forEach(i=>used.add(i))}
 if(groups.length<2&&objective.simultaneous===2){for(let a=0;a<candidates.length;a++)for(let b=a+1;b<candidates.length;b++){if(candidates[a].ids.some(i=>candidates[b].ids.includes(i)))continue;return{groups:[candidates[a],candidates[b]],ids:[...candidates[a].ids,...candidates[b].ids]}}}
 if(groups.length<(objective.simultaneous||1))return{groups:[],ids:[]};return{groups,ids:[...used]};
}
function proximity(grid,o){if(!o)return 1;const candidates=[];for(const cells of patterns[o.shape]){const h=Math.max(...cells.map(p=>p[0]))+1,w=Math.max(...cells.map(p=>p[1]))+1;for(let r=0;r<=N-h;r++)for(let c=0;c<=N-w;c++){if(o.anchor&&(r!==o.anchor[0]||c!==o.anchor[1]))continue;const counts=Array(5).fill(0),ids=[];for(const [dr,dc] of cells){counts[value(grid[r+dr][c+dc])]++;ids.push((r+dr)*6+c+dc)}candidates.push({score:o.color==null?Math.max(...counts):counts[o.color],ids})}}candidates.sort((a,b)=>b.score-a.score);let score=0,count=0;const used=new Set();for(const p of candidates){if(p.ids.some(i=>used.has(i)))continue;score+=p.score;p.ids.forEach(i=>used.add(i));if(++count===(o.simultaneous||1))break}return score/(SHAPES[o.shape].cells.length*(o.simultaneous||1))}
function seeded(seed){let state=seed|0;const next=()=>{state=state+0x6D2B79F5|0;let t=Math.imul(state^state>>>15,1|state);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296};next.getState=()=>state;next.setState=n=>{state=n|0};return next}
function collapse(grid,ids,spawn){const removed=new Set(ids),next=grid.map(row=>row.slice()),falls=[];for(let c=0;c<N;c++){const kept=[];for(let r=0;r<N;r++)if(!removed.has(r*N+c))kept.push({tile:grid[r][c],old:r});const missing=N-kept.length;if(!missing)continue;for(let r=N-1;r>=0;r--){if(r>=missing){const k=kept[r-missing];next[r][c]=k.tile;if(k.old!==r)falls.push({r,c,from:k.old-r,fresh:false})}else{next[r][c]=spawn();falls.push({r,c,from:-(missing-r+.8),fresh:true,missing})}}}return{grid:next,falls}}
function puzzleState(config){return{grid:config.board.map(row=>row.slice()),objectiveIndex:0,progress:0,movesLeft:config.moves,rngState:config.seed+77}}
// Resolve all ready objectives in order without spending another move.
function settlePuzzle(state,config){let grid=state.grid,progress=state.progress,objectiveIndex=state.objectiveIndex,chain=0;const rand=seeded(state.rngState);
 for(let guard=0;guard<30*config.objectives.length;guard++){
 const objective=config.objectives[objectiveIndex];if(!objective)break;const m=figureMatch(grid,objective);if(!m.ids.length)break;
 progress+=m.groups.length;grid=collapse(grid,m.ids,()=>Math.floor(rand()*5)).grid;chain++;
 if(progress>=objective.count){objectiveIndex++;progress=0;chain=0}else if(chain>=30)break;
 }
 return{...state,grid,objectiveIndex,progress,rngState:rand.getState()};
}
function simulatePuzzle(state,move,config){if(state.objectiveIndex>=config.objectives.length||state.movesLeft<=0)return state;return settlePuzzle({...state,grid:shifted(state.grid,move.axis,move.index,move.n),movesLeft:state.movesLeft-1},config)}
const ALL_MOVES=['x','y'].flatMap(axis=>Array.from({length:6},(_,index)=>[1,-1,2,-2,3].map(n=>({axis,index,n}))).flat());
function puzzleHint(grid,objective,depth=2){for(const move of ALL_MOVES){if(figureMatch(shifted(grid,move.axis,move.index,move.n),objective).ids.length)return{...move,preparation:false}}
 if(depth>1)for(const first of ALL_MOVES){const next=shifted(grid,first.axis,first.index,first.n);for(const second of ALL_MOVES){if(first.axis===second.axis&&first.index===second.index)continue;if(figureMatch(shifted(next,second.axis,second.index,second.n),objective).ids.length)return{...first,preparation:true}}}return null}

// Curated tasks with fixed boards and independently replayable solutions.
const PUZZLES=[
 {
  "title": "Первый сдвиг",
  "moves": 5,
  "objectives": [
   {
    "shape": "square",
    "count": 1
   }
  ],
  "minFirst": 1,
  "id": 1,
  "seed": 12009,
  "board": [
   [
    0,
    1,
    1,
    1,
    1,
    0
   ],
   [
    2,
    3,
    2,
    0,
    1,
    3
   ],
   [
    4,
    0,
    3,
    1,
    0,
    3
   ],
   [
    1,
    3,
    4,
    1,
    0,
    4
   ],
   [
    3,
    2,
    1,
    1,
    0,
    0
   ],
   [
    1,
    1,
    0,
    1,
    3,
    1
   ]
  ],
  "solution": [
   {
    "axis": "x",
    "index": 4,
    "n": -2
   }
  ]
 },
 {
  "title": "Поймай ритм",
  "moves": 7,
  "objectives": [
   {
    "shape": "square",
    "count": 2
   }
  ],
  "minFirst": 1,
  "id": 2,
  "seed": 24017,
  "board": [
   [
    3,
    4,
    4,
    3,
    1,
    2
   ],
   [
    0,
    3,
    4,
    3,
    2,
    4
   ],
   [
    4,
    0,
    1,
    3,
    2,
    1
   ],
   [
    2,
    2,
    4,
    0,
    3,
    4
   ],
   [
    4,
    1,
    1,
    1,
    0,
    3
   ],
   [
    3,
    4,
    3,
    4,
    1,
    3
   ]
  ],
  "solution": [
   {
    "axis": "y",
    "index": 1,
    "n": 1
   },
   {
    "axis": "y",
    "index": 0,
    "n": 2
   }
  ]
 },
 {
  "title": "Голубая цель",
  "moves": 6,
  "objectives": [
   {
    "shape": "square",
    "count": 1,
    "color": 1
   }
  ],
  "minFirst": 1,
  "id": 3,
  "seed": 36022,
  "board": [
   [
    1,
    2,
    3,
    2,
    2,
    4
   ],
   [
    3,
    1,
    1,
    2,
    1,
    2
   ],
   [
    1,
    2,
    0,
    1,
    2,
    1
   ],
   [
    0,
    3,
    2,
    2,
    0,
    3
   ],
   [
    3,
    2,
    2,
    2,
    3,
    1
   ],
   [
    2,
    3,
    3,
    0,
    0,
    4
   ]
  ],
  "solution": [
   {
    "axis": "x",
    "index": 2,
    "n": 2
   }
  ]
 },
 {
  "title": "Точное место",
  "moves": 4,
  "objectives": [
   {
    "shape": "square",
    "count": 1,
    "anchor": [
     2,
     2
    ]
   }
  ],
  "minFirst": 2,
  "id": 4,
  "seed": 48029,
  "board": [
   [
    0,
    1,
    4,
    2,
    4,
    0
   ],
   [
    0,
    1,
    3,
    4,
    2,
    1
   ],
   [
    3,
    3,
    4,
    3,
    3,
    4
   ],
   [
    3,
    3,
    1,
    3,
    0,
    1
   ],
   [
    0,
    0,
    0,
    0,
    1,
    0
   ],
   [
    4,
    0,
    4,
    3,
    4,
    1
   ]
  ],
  "solution": [
   {
    "axis": "x",
    "index": 2,
    "n": -1
   },
   {
    "axis": "x",
    "index": 3,
    "n": 2
   }
  ]
 },
 {
  "title": "Два розовых",
  "moves": 7,
  "objectives": [
   {
    "shape": "square",
    "count": 2,
    "color": 0
   }
  ],
  "minFirst": 2,
  "id": 5,
  "seed": 60053,
  "board": [
   [
    1,
    1,
    0,
    1,
    3,
    0
   ],
   [
    0,
    0,
    4,
    1,
    0,
    4
   ],
   [
    1,
    2,
    3,
    3,
    3,
    2
   ],
   [
    2,
    0,
    3,
    0,
    2,
    4
   ],
   [
    3,
    0,
    4,
    2,
    3,
    2
   ],
   [
    1,
    2,
    1,
    0,
    0,
    2
   ]
  ],
  "solution": [
   {
    "axis": "x",
    "index": 1,
    "n": -2
   },
   {
    "axis": "y",
    "index": 1,
    "n": 3
   },
   {
    "axis": "x",
    "index": 0,
    "n": -1
   },
   {
    "axis": "y",
    "index": 3,
    "n": 1
   },
   {
    "axis": "x",
    "index": 0,
    "n": 1
   }
  ]
 },
 {
  "title": "Сначала — потом",
  "moves": 5,
  "objectives": [
   {
    "shape": "square",
    "count": 1,
    "color": 1
   },
   {
    "shape": "square",
    "count": 1,
    "color": 2
   }
  ],
  "minFirst": 2,
  "id": 6,
  "seed": 72059,
  "board": [
   [
    1,
    0,
    0,
    1,
    1,
    0
   ],
   [
    1,
    4,
    1,
    3,
    2,
    2
   ],
   [
    1,
    0,
    0,
    3,
    2,
    2
   ],
   [
    4,
    4,
    2,
    3,
    4,
    1
   ],
   [
    0,
    0,
    1,
    1,
    3,
    1
   ],
   [
    4,
    4,
    4,
    1,
    0,
    3
   ]
  ],
  "solution": [
   {
    "axis": "x",
    "index": 0,
    "n": -1
   },
   {
    "axis": "y",
    "index": 2,
    "n": -2
   }
  ]
 },
 {
  "title": "Дальний угол",
  "moves": 4,
  "objectives": [
   {
    "shape": "square",
    "count": 1,
    "color": 4,
    "anchor": [
     3,
     3
    ]
   }
  ],
  "minFirst": 2,
  "id": 7,
  "seed": 84049,
  "board": [
   [
    2,
    2,
    4,
    1,
    1,
    2
   ],
   [
    0,
    1,
    0,
    0,
    4,
    4
   ],
   [
    2,
    0,
    4,
    4,
    3,
    0
   ],
   [
    4,
    4,
    2,
    2,
    2,
    1
   ],
   [
    2,
    3,
    4,
    0,
    4,
    4
   ],
   [
    1,
    4,
    0,
    2,
    0,
    3
   ]
  ],
  "solution": [
   {
    "axis": "x",
    "index": 3,
    "n": 3
   },
   {
    "axis": "x",
    "index": 4,
    "n": -1
   }
  ]
 },
 {
  "title": "Двойной всплеск",
  "moves": 4,
  "objectives": [
   {
    "shape": "square",
    "count": 2,
    "simultaneous": 2
   }
  ],
  "minFirst": 2,
  "id": 8,
  "seed": 96056,
  "board": [
   [
    2,
    2,
    0,
    1,
    2,
    1
   ],
   [
    3,
    3,
    4,
    1,
    4,
    3
   ],
   [
    3,
    0,
    3,
    3,
    1,
    2
   ],
   [
    1,
    2,
    4,
    4,
    1,
    0
   ],
   [
    2,
    1,
    3,
    3,
    2,
    2
   ],
   [
    1,
    3,
    2,
    0,
    3,
    3
   ]
  ],
  "solution": [
   {
    "axis": "x",
    "index": 4,
    "n": 2
   },
   {
    "axis": "x",
    "index": 1,
    "n": 2
   }
  ]
 },
 {
  "title": "Две остановки",
  "moves": 7,
  "objectives": [
   {
    "shape": "square",
    "count": 1,
    "anchor": [
     0,
     0
    ]
   },
   {
    "shape": "square",
    "count": 1,
    "anchor": [
     3,
     3
    ]
   }
  ],
  "minFirst": 2,
  "id": 9,
  "seed": 108065,
  "board": [
   [
    4,
    0,
    3,
    0,
    0,
    2
   ],
   [
    3,
    2,
    3,
    3,
    1,
    4
   ],
   [
    2,
    4,
    1,
    2,
    2,
    3
   ],
   [
    2,
    0,
    3,
    3,
    0,
    0
   ],
   [
    0,
    4,
    4,
    1,
    2,
    1
   ],
   [
    2,
    1,
    3,
    2,
    3,
    3
   ]
  ],
  "solution": [
   {
    "axis": "x",
    "index": 0,
    "n": 2
   },
   {
    "axis": "y",
    "index": 0,
    "n": -2
   },
   {
    "axis": "y",
    "index": 4,
    "n": -2
   },
   {
    "axis": "x",
    "index": 0,
    "n": 3
   },
   {
    "axis": "y",
    "index": 3,
    "n": 3
   }
  ]
 },
 {
  "title": "Розовый дуэт",
  "moves": 4,
  "objectives": [
   {
    "shape": "square",
    "count": 2,
    "color": 0,
    "simultaneous": 2
   }
  ],
  "minFirst": 3,
  "id": 10,
  "seed": 120096,
  "board": [
   [
    0,
    0,
    2,
    0,
    4,
    0
   ],
   [
    4,
    0,
    4,
    0,
    0,
    4
   ],
   [
    0,
    2,
    1,
    1,
    2,
    2
   ],
   [
    1,
    3,
    0,
    0,
    3,
    1
   ],
   [
    3,
    0,
    3,
    3,
    4,
    0
   ],
   [
    3,
    0,
    3,
    1,
    4,
    0
   ]
  ],
  "solution": [
   {
    "axis": "x",
    "index": 0,
    "n": -2
   },
   {
    "axis": "x",
    "index": 2,
    "n": 2
   },
   {
    "axis": "y",
    "index": 1,
    "n": 2
   }
  ]
 },
 {
  "title": "В одну линию",
  "moves": 4,
  "objectives": [
   {
    "shape": "line",
    "count": 1
   }
  ],
  "minFirst": 1,
  "id": 11,
  "seed": 132078,
  "board": [
   [
    2,
    3,
    4,
    4,
    3,
    2
   ],
   [
    4,
    4,
    3,
    0,
    0,
    1
   ],
   [
    1,
    4,
    1,
    3,
    1,
    1
   ],
   [
    2,
    2,
    4,
    4,
    2,
    2
   ],
   [
    1,
    2,
    2,
    1,
    1,
    3
   ],
   [
    1,
    1,
    2,
    3,
    4,
    4
   ]
  ],
  "solution": [
   {
    "axis": "x",
    "index": 3,
    "n": 2
   }
  ]
 },
 {
  "title": "Лазурная дорожка",
  "moves": 3,
  "objectives": [
   {
    "shape": "line",
    "count": 1,
    "color": 1
   }
  ],
  "minFirst": 2,
  "id": 12,
  "seed": 144087,
  "board": [
   [
    3,
    3,
    3,
    4,
    2,
    3
   ],
   [
    1,
    2,
    4,
    3,
    3,
    3
   ],
   [
    4,
    1,
    2,
    3,
    1,
    3
   ],
   [
    2,
    4,
    1,
    1,
    3,
    2
   ],
   [
    4,
    3,
    4,
    3,
    1,
    2
   ],
   [
    2,
    2,
    1,
    3,
    3,
    3
   ]
  ],
  "solution": [
   {
    "axis": "x",
    "index": 1,
    "n": -2
   },
   {
    "axis": "x",
    "index": 3,
    "n": 1
   }
  ]
 },
 {
  "title": "Поворот мысли",
  "moves": 4,
  "objectives": [
   {
    "shape": "corner",
    "count": 1
   }
  ],
  "minFirst": 1,
  "id": 13,
  "seed": 156091,
  "board": [
   [
    3,
    3,
    1,
    0,
    3,
    2
   ],
   [
    2,
    3,
    0,
    0,
    1,
    4
   ],
   [
    3,
    3,
    2,
    3,
    2,
    4
   ],
   [
    1,
    3,
    3,
    4,
    3,
    0
   ],
   [
    4,
    0,
    1,
    4,
    4,
    4
   ],
   [
    2,
    2,
    3,
    3,
    1,
    1
   ]
  ],
  "solution": [
   {
    "axis": "x",
    "index": 2,
    "n": -2
   }
  ]
 },
 {
  "title": "Зелёный уголок",
  "moves": 3,
  "objectives": [
   {
    "shape": "corner",
    "count": 1,
    "color": 4
   }
  ],
  "minFirst": 2,
  "id": 14,
  "seed": 168113,
  "board": [
   [
    1,
    3,
    0,
    3,
    1,
    1
   ],
   [
    0,
    4,
    3,
    3,
    2,
    1
   ],
   [
    4,
    0,
    4,
    2,
    2,
    3
   ],
   [
    4,
    4,
    0,
    3,
    4,
    0
   ],
   [
    3,
    0,
    4,
    2,
    1,
    2
   ],
   [
    4,
    3,
    1,
    1,
    4,
    3
   ]
  ],
  "solution": [
   {
    "axis": "x",
    "index": 1,
    "n": -1
   },
   {
    "axis": "y",
    "index": 2,
    "n": 1
   }
  ]
 },
 {
  "title": "Смена формы",
  "moves": 4,
  "objectives": [
   {
    "shape": "square",
    "count": 1,
    "color": 0
   },
   {
    "shape": "line",
    "count": 1,
    "color": 1
   }
  ],
  "minFirst": 2,
  "id": 15,
  "seed": 180129,
  "board": [
   [
    2,
    4,
    3,
    0,
    2,
    4
   ],
   [
    3,
    4,
    4,
    1,
    3,
    1
   ],
   [
    3,
    1,
    2,
    2,
    3,
    4
   ],
   [
    3,
    3,
    4,
    4,
    1,
    0
   ],
   [
    0,
    0,
    4,
    1,
    3,
    0
   ],
   [
    0,
    2,
    4,
    3,
    0,
    3
   ]
  ],
  "solution": [
   {
    "axis": "x",
    "index": 0,
    "n": 1
   },
   {
    "axis": "y",
    "index": 4,
    "n": -2
   },
   {
    "axis": "x",
    "index": 2,
    "n": -2
   }
  ]
 },
 {
  "title": "Уголок на месте",
  "moves": 3,
  "objectives": [
   {
    "shape": "corner",
    "count": 1,
    "anchor": [
     1,
     2
    ]
   }
  ],
  "minFirst": 2,
  "id": 16,
  "seed": 192113,
  "board": [
   [
    1,
    2,
    4,
    3,
    3,
    1
   ],
   [
    3,
    2,
    1,
    2,
    4,
    2
   ],
   [
    2,
    0,
    3,
    2,
    4,
    3
   ],
   [
    3,
    3,
    1,
    2,
    3,
    3
   ],
   [
    2,
    1,
    4,
    1,
    3,
    3
   ],
   [
    2,
    3,
    3,
    1,
    3,
    2
   ]
  ],
  "solution": [
   {
    "axis": "x",
    "index": 3,
    "n": -2
   },
   {
    "axis": "x",
    "index": 1,
    "n": 2
   }
  ]
 },
 {
  "title": "Дорожка к звезде",
  "moves": 4,
  "objectives": [
   {
    "shape": "line",
    "count": 1,
    "color": 2
   },
   {
    "shape": "corner",
    "count": 1,
    "color": 3
   }
  ],
  "minFirst": 2,
  "id": 17,
  "seed": 204125,
  "board": [
   [
    3,
    2,
    4,
    4,
    4,
    3
   ],
   [
    3,
    1,
    0,
    2,
    2,
    3
   ],
   [
    2,
    1,
    4,
    4,
    4,
    1
   ],
   [
    0,
    0,
    2,
    1,
    3,
    4
   ],
   [
    3,
    1,
    2,
    3,
    2,
    0
   ],
   [
    1,
    4,
    4,
    4,
    4,
    4
   ]
  ],
  "solution": [
   {
    "axis": "y",
    "index": 1,
    "n": -2
   },
   {
    "axis": "y",
    "index": 3,
    "n": 3
   },
   {
    "axis": "x",
    "index": 2,
    "n": 3
   }
  ]
 },
 {
  "title": "Параллели",
  "moves": 3,
  "objectives": [
   {
    "shape": "line",
    "count": 2,
    "simultaneous": 2
   }
  ],
  "minFirst": 2,
  "id": 18,
  "seed": 216131,
  "board": [
   [
    0,
    1,
    2,
    4,
    1,
    4
   ],
   [
    1,
    4,
    2,
    0,
    1,
    2
   ],
   [
    2,
    2,
    1,
    0,
    3,
    0
   ],
   [
    3,
    3,
    3,
    0,
    4,
    3
   ],
   [
    3,
    4,
    1,
    1,
    1,
    4
   ],
   [
    3,
    0,
    3,
    4,
    1,
    2
   ]
  ],
  "solution": [
   {
    "axis": "x",
    "index": 0,
    "n": 3
   },
   {
    "axis": "y",
    "index": 1,
    "n": -2
   }
  ]
 },
 {
  "title": "Три превращения",
  "moves": 5,
  "objectives": [
   {
    "shape": "corner",
    "count": 1
   },
   {
    "shape": "square",
    "count": 1,
    "color": 0
   },
   {
    "shape": "line",
    "count": 1,
    "color": 1
   }
  ],
  "minFirst": 2,
  "id": 19,
  "seed": 228136,
  "board": [
   [
    2,
    4,
    0,
    2,
    0,
    0
   ],
   [
    3,
    2,
    4,
    4,
    0,
    0
   ],
   [
    1,
    4,
    2,
    1,
    0,
    3
   ],
   [
    4,
    4,
    1,
    2,
    1,
    4
   ],
   [
    3,
    0,
    2,
    2,
    4,
    0
   ],
   [
    2,
    1,
    1,
    3,
    2,
    0
   ]
  ],
  "solution": [
   {
    "axis": "x",
    "index": 4,
    "n": 3
   },
   {
    "axis": "y",
    "index": 1,
    "n": -1
   },
   {
    "axis": "x",
    "index": 3,
    "n": -1
   }
  ]
 },
 {
  "title": "Лунный экзамен",
  "moves": 6,
  "objectives": [
   {
    "shape": "square",
    "count": 1,
    "anchor": [
     2,
     2
    ]
   },
   {
    "shape": "line",
    "count": 1,
    "color": 1
   },
   {
    "shape": "corner",
    "count": 1,
    "color": 3
   }
  ],
  "minFirst": 3,
  "id": 20,
  "seed": 240172,
  "board": [
   [
    0,
    0,
    1,
    3,
    0,
    2
   ],
   [
    2,
    1,
    4,
    3,
    4,
    1
   ],
   [
    0,
    1,
    2,
    1,
    3,
    3
   ],
   [
    0,
    0,
    2,
    0,
    1,
    4
   ],
   [
    2,
    4,
    1,
    1,
    3,
    3
   ],
   [
    1,
    1,
    0,
    0,
    1,
    2
   ]
  ],
  "solution": [
   {
    "axis": "x",
    "index": 0,
    "n": 2
   },
   {
    "axis": "y",
    "index": 2,
    "n": 3
   },
   {
    "axis": "y",
    "index": 3,
    "n": 3
   },
   {
    "axis": "y",
    "index": 1,
    "n": 1
   },
   {
    "axis": "x",
    "index": 3,
    "n": 1
   }
  ]
 }
];

const chapters=[
 ['Колыбель звёзд','Собирай квадраты 2 × 2'],['Опаловая туманность','Разбивай стекло под желейками'],
 ['Кольца Авроры','Собирай нужный цвет'],['Пульсарные печати','Найди ключ для закрытого ряда'],
 ['Кометный пояс','Связанные ряды движутся навстречу'],['Созвездия','Два ряда движутся вместе'],
 ['Зеркальные луны','Каждый третий ход сдвигает ряд'],['Лунные испытания','Стекло в два слоя'],
 ['Сердце галактики','Сочетай знакомые правила'],['Маяк бесконечности','Все секреты лунного желе']];
function random(seed){return()=>{seed|=0;seed=seed+0x6D2B79F5|0;let t=Math.imul(seed^seed>>>15,1|seed);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
function level(number){
 const id=Math.min(500,Math.max(1,Math.floor(number)||1)),chapter=Math.floor((id-1)/50),stage=(id-1)%50,rand=random(id*719+319);
 if(id<=20){const puzzle=PUZZLES[id-1];return {...puzzle,puzzleTitle:puzzle.title,authored:true,revision:2,chapter:0,stage:id-1,title:chapters[0][0],color:null,goal:0,glass:Array(36).fill(0),lockRow:null,key:null,pair:null,tide:null};}
 if(id<=500){const modern=globalThis.SDVIG_LEVELS.find(l=>l.id===id);return {...modern,title:chapters[chapter][0]};}
 const color=id>=21&&stage%4===0?Math.floor(rand()*5):null;
 const glass=id>=11&&!(stage%5===0),lock=id>=31&&(chapter===3||stage%3===0),pair=id>=41?(chapter<5?'opposite':chapter===5?'same':stage%3===1?'same':stage%3===2?'opposite':null):null;
 const tide=chapter>=6&&stage%3===0;
 const cells=Array.from({length:36},(_,i)=>i);for(let i=35;i>0;i--){const j=Math.floor(rand()*(i+1));[cells[i],cells[j]]=[cells[j],cells[i]]}
 const count=glass?Math.min(20,4+Math.floor(stage/5)+(chapter>=7?4:0)):0;
 const terrain=Array(36).fill(0);cells.slice(0,count).forEach((i,k)=>terrain[i]=chapter>=7&&k%3===0?2:1);
 const goal=glass?0:color!==null?12+Math.floor(stage/10)*4:id===1?2:3+Math.floor(stage/8);
 return{id,chapter,stage,title:chapters[chapter][0],moves:id===1?12:20+Math.floor(count*.6)+Math.floor(goal*.6),color,goal,glass:terrain,lockRow:lock?4:null,key:lock?7+(stage%3):null,pair:pair?{axis:stage%2?'y':'x',a:1,b:4,mode:pair}:null,tide:tide?{axis:stage%2?'x':'y',index:2}:null,seed:id*8917+2026};
}
function lineMoves(config,axis,index,n,locked){
 if(config.modern)return C.lineMoves({locked,pins:mPins,routeSide:mExtra.routeSide,turn:drag?.settling&&!drag.tide?turns-1:turns},config,axis,index,n);
 if(locked&&axis==='x'&&index===config.lockRow)return[];
 const result=[{axis,index,n}],p=config.pair;
 if(p&&axis===p.axis&&(index===p.a||index===p.b)){
 const other=index===p.a?p.b:p.a;
 if(locked&&axis==='x'&&other===config.lockRow)return[];
 result.push({axis,index:other,n:p.mode==='opposite'?-n:n});}
 return result;
}
function applyMoves(grid,moves){return moves.reduce((g,m)=>config.modern?C.routeShift(g,m.axis,m.index,m.n,{pins:mPins,routeSide:mExtra.routeSide},config):shifted(g,m.axis,m.index,m.n),grid)}
function legalHint(grid,config,locked){for(const n of [1,-1,2,-2,3])for(const axis of ['x','y'])for(let index=0;index<N;index++){const moves=lineMoves(config,axis,index,n,locked);if(moves.length&&squares(applyMoves(grid,moves)).ids.length)return{axis,index,n}}return null}
function initial(config){if(config.modern)return C.initial(config).grid;if(config.authored)return config.board.map(row=>row.map(color=>({color})));const rand=random(config.seed);for(let trial=0;trial<10000;trial++){const g=Array.from({length:N},()=>Array.from({length:N},()=>({color:Math.floor(rand()*5)})));if(!squares(g).ids.length&&legalHint(g,config,config.lockRow!==null))return g}throw Error('No playable board '+config.id)}
function damage(terrain,ids){const next=terrain.slice();for(const i of new Set(ids))next[i]=Math.max(0,next[i]-1);return next}

const canvas=document.querySelector('#board'),ctx=canvas.getContext('2d');
const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
const names=['coral','aqua','lemon','violet','mint'];
const colors=['#ff327b','#00cfec','#ffce15','#a45eff','#55d82f'];
const sprites=[],sadSprites=[],glassSprites=[],glassShards=[],particles=[],ripples=[];
const lockArt=[],mechanicArt=[],extraArt={},hardwareFX=[];
let mExtra={},modernPlayback=null;
let mPins=[],mProgress=[0,0,0,0,0],mBombUsed=0,mBombsMade=0;
let glassMasks=null;
let size=500,step=size/N,dpr=1,grid=[],drag=null,phase=null;
let busy=false,paused=false,score=0,best=1,sound=false,audio=null;
let time=0,last=performance.now(),selected={r:2,c:2},ready=false,history=[],toastUntil=0;
const $=s=>document.querySelector(s),rnd=n=>Math.floor(Math.random()*n);
let config=level(1),terrain=[],locked=false,key=null,movesLeft=0,collected=0,turns=0,unlocked=1,completed={},rng=Math.random,activeTool=null,tools={hammer:1,nova:1},finished=false;
let roadPosition=1,pendingRoadMove=null;
let tidePending=false,objectiveIndex=0,stageProgress=0,stageComplete=false;
function readSave(){try{
 const testing=new URLSearchParams(location.search).get('test')==='1';
 const own=localStorage.getItem(testing?'sdvig-v14-sandbox':'sdvig-campaign-v14');if(own)return JSON.parse(own);
 const previous=localStorage.getItem(testing?'sdvig-v13-sandbox':'sdvig-campaign-v13');if(previous){const old=JSON.parse(previous);return {...old,board:(old.current||1)<=20?old.board:null};}
 if(testing)return null;
 const raw=localStorage.getItem('sdvig-campaign-v12-test');if(!raw)return null;
 const old=JSON.parse(raw),completed=old.completed&&typeof old.completed==='object'?old.completed:{};
 const highest=Math.max(0,...Object.keys(completed).filter(k=>completed[k]>0&&Number(k)<=500).map(Number));
 const unlocked=old.unlocked===500?Math.min(500,highest+1):Math.min(500,Math.max(1,Number(old.unlocked)||1));
 return {...old,completed,unlocked,current:Math.min(old.current||1,unlocked),board:old.current<=20?old.board:null};
}catch{return null}}
try{const save=readSave();if(save){unlocked=Math.min(500,Math.max(1,save.unlocked||1));completed=save.completed||{};roadPosition=Math.max(1,Math.min(unlocked,Number(save.roadPosition)||unlocked));pendingRoadMove=validRoadMove(save.pendingRoadMove,unlocked)?save.pendingRoadMove:null;config=level(Math.min(save.current||unlocked,unlocked));}}catch{}
const TEST_MODE=new URLSearchParams(location.search).get('test')==='1';
if(TEST_MODE){unlocked=500;pendingRoadMove=null;document.documentElement.dataset.test='true';}
const duration=ms=>reduced?Math.min(ms,100):ms;
try{best=Math.max(1,Number(localStorage.getItem('sdvig-best'))||1);sound=localStorage.getItem('sdvig-sound')==='true'}catch{}
function tile(color=Math.floor(rng()*5)){return{color,wiggle:Math.random()*Math.PI*2,fall:null,pop:null,tap:-1000,land:-1000,landAxis:'x'}}
function updateControls(){
 document.documentElement.dataset.busy=String(busy);
 $('#undo').disabled=!history.length||busy||paused;
 $('#reset').disabled=!ready||paused;
 $('#burst').disabled=!ready||busy||paused;
 $('#score').textContent=config.authored?(currentObjective()?Math.min(stageProgress,currentObjective().count)+' / '+currentObjective().count:'✓'):config.glass.some(Boolean)?terrain.filter(Boolean).length+' / '+config.glass.filter(Boolean).length:Math.min(config.goal,collected)+' / '+config.goal;$('#best').textContent=movesLeft;
 updateJourneyUI();$('#levels').textContent='Карта · '+config.id+' / 500';$('#chapter-name').textContent=config.puzzleTitle||config.title;drawGoalPreview();document.documentElement.dataset.authored=String(!!(config.authored||config.modern));
 $('#rules').textContent=config.authored?(currentObjective()?objectiveText(currentObjective()):'Готово!'):ruleText().split(' · ')[0];$('#help-text').textContent=ruleText();for(const name of ['hammer','nova']){const b=$('#'+name);b.disabled=busy||paused||finished||!tools[name]||config.authored;b.classList.toggle('selected',activeTool===name);b.querySelector('small').textContent=tools[name]}
 $('#burst').disabled ||= finished;
 if(!busy&&ready&&!finished)saveCampaign();
 canvas.dataset.squares=String(score);canvas.dataset.level=String(config.id);canvas.dataset.objective=String(objectiveIndex);canvas.dataset.progress=String(stageProgress);
 canvas.dataset.state=paused?'paused':!ready?'loading':busy?'animating':'idle';
 canvas.dataset.phase=drag?.settling?'slide':phase?.kind||'idle';
 canvas.dataset.pins=String(mPins.length);canvas.dataset.bombs=String(grid.flat().filter(t=>t.bomb).length);canvas.dataset.bombsUsed=String(mBombUsed);canvas.dataset.modern=String(!!config.modern);
 canvas.dataset.glassTiles=String(terrain.filter(Boolean).length);canvas.dataset.glassLayers=String(terrain.reduce((a,b)=>a+b,0));
}
const chapterNames=['Колыбель звёзд','Опаловая туманность','Кольца Авроры','Пульсарные печати','Кометный пояс','Созвездия','Зеркальные луны','Лунные испытания','Сердце галактики','Маяк бесконечности'];
function updateJourneyUI(){
 const chapter=config.chapter;$('#chapter-progress').textContent=(TEST_MODE?'ПЕСОЧНИЦА · ':'')+'Глава '+(chapter+1)+' · '+chapterNames[chapter];
 $('#chapter-meter-fill').style.width=((config.stage+1)*2)+'%';
 const status=[];if(config.detour)status.push((mExtra.routeSide||-1)<0?'Объезд ↑ / ←':'Объезд ↓ / →');if(config.compass)status.push(turns%2?'↕ Вертикаль':'↔ Горизонталь');if(config.singleStep)status.push('Шаг ±1');if(config.tide)status.push('Прилив через '+(config.tide.every-turns%config.tide.every));
 $('#turn-rule').textContent=status.join(' · ')||'Свободный сдвиг';
 $('#help-title').textContent=config.puzzleTitle||'Правила уровня';
 document.querySelector('footer small').textContent=TEST_MODE?'ПЕСОЧНИЦА · прогресс отдельно':'Сквозь звёзды · 0.16';
 $('#test-jump').hidden=!TEST_MODE;$('#test-shortcuts').hidden=!TEST_MODE;
}
for(const button of document.querySelectorAll('[data-try-level]'))button.onclick=()=>{if(TEST_MODE){$('#level-dialog').close();startLevel(Number(button.dataset.tryLevel));}};
$('#test-go').onclick=()=>{const id=Number($('#test-level').value);if(TEST_MODE&&Number.isInteger(id)&&id>=1&&id<=500){$('#level-dialog').close();startLevel(id)}};
function currentObjective(){return config.authored?config.objectives[objectiveIndex]:null}
function objectiveText(o){const color=o.color==null?'Любой цвет':COLOR_NAMES[o.color]+' цвет';return (o.simultaneous?'Две фигуры одновременно':SHAPES[o.shape].name+(o.count>1?' × '+o.count:''))+' · '+color+(o.anchor?' · На отметке':'')}
let lastGoalSignature='';
function drawGoalPreview(){
 if(config.modern){drawModernGoals();return}
 const signature=JSON.stringify([config.id,objectiveIndex,stageProgress,collected,terrain,locked]);
 if(signature===lastGoalSignature)return;lastGoalSignature=signature;
 const holder=$('#goal-pattern');holder.replaceChildren();
 const glassGoal=!config.authored&&config.glass.some(Boolean),colorGoal=!config.authored&&!glassGoal&&config.color!==null;
 const list=config.authored?config.objectives:[{shape:'square',color:config.color,count:config.goal}];
 list.forEach((o,i)=>{
  const past=config.authored&&i<objectiveIndex,future=config.authored&&i>objectiveIndex;
  const card=document.createElement('div');card.className='quest-card '+(past?'past':future?'future':'current');card.dataset.stage=i;
  if(!past&&!future)card.setAttribute('aria-current','step');
  const number=document.createElement('span');number.className='quest-number';number.textContent=past?'✓':String(i+1);card.append(number);
  const art=document.createElement('div');art.className='quest-art';
  const copies=o.simultaneous||1;
  for(let copy=0;copy<copies;copy++){
   const cells=colorGoal||glassGoal?[[0,0]]:SHAPES[o.shape].cells,w=Math.max(...cells.map(p=>p[1]))+1,h=Math.max(...cells.map(p=>p[0]))+1;
   const figure=document.createElement('div');figure.className='mini-figure'+(glassGoal?' glass-example':'');figure.style.setProperty('--cols',w);figure.style.setProperty('--rows',h);
   figure.setAttribute('aria-label',(colorGoal?COLOR_NAMES[o.color]+' цвет':SHAPES[o.shape].name)+(o.color==null?' · любой цвет':' · '+COLOR_NAMES[o.color]));
   cells.forEach(([r,c],j)=>{const img=document.createElement('img');img.src='assets/jelly-'+names[o.color??(copy===1?0:1)]+(glassGoal?'-sad.webp':'-opal.webp');img.alt='';img.draggable=false;img.style.gridRow=String(r+1);img.style.gridColumn=String(c+1);figure.append(img)});if(glassGoal){const pane=document.createElement('img');pane.src='assets/tile-glass-clear.webp';pane.alt='Стекло';pane.draggable=false;figure.append(pane)}art.append(figure);
  }
  card.append(art);
  const copy=document.createElement('div');copy.className='quest-copy';const title=document.createElement('b');
  const adjective=o.color==null?'':(o.shape==='line'?['Розовая','Голубая','Жёлтая','Фиолетовая','Зелёная']:COLOR_NAMES)[o.color]+' ';
  title.textContent=glassGoal?'Разбей стекло':colorGoal?'Собери желейки':adjective+(adjective?SHAPES[o.shape].name.toLowerCase():SHAPES[o.shape].name);
  const detail=document.createElement('span');detail.className='quest-detail';detail.textContent=past?'Готово':glassGoal?'Сними все слои':colorGoal?COLOR_NAMES[o.color]+' цвет':[o.anchor?'На отметке':null,o.color==null?'Любой цвет':null,o.simultaneous?'Две сразу':null].filter(Boolean).join(' · ')||'Собери фигуру';
  const progress=document.createElement('small');progress.className='quest-progress';
  const value=past?o.count:future?0:config.authored?Math.min(stageProgress,o.count):glassGoal?config.glass.filter(Boolean).length-terrain.filter(Boolean).length:Math.min(collected,config.goal);
  const total=glassGoal?config.glass.filter(Boolean).length:o.count;
  progress.textContent=past?'✓':value+' / '+total;copy.append(title,detail);card.append(copy,progress);holder.append(card);
 });
 $('#goal-stage').textContent=config.authored&&list.length>1?(Math.min(objectiveIndex+1,list.length)+' / '+list.length):'';
 $('#score-label').textContent=config.authored?'ФИГУРЫ':'ЦЕЛЬ';
 const notes=config.authored?[]:ruleText().split(' · ').slice(1);$('#mechanic-notes').textContent=notes.join(' · ');$('#mechanic-notes').hidden=!notes.length;
 $('#help-extra').textContent=config.authored?'Следующие фигуры ждут своего этапа. Если новая цель уже собрана, она исчезнет автоматически без дополнительного хода. «Показать» выполняет ход и тратит один ход. «Назад» возвращает предыдущий ход. Бустеры появятся после вводных уровней.':'Луч убирает одну желейку и слой стекла под ней. Нова убирает строку и столбец. Каждый бустер расходует один ход. «Показать» выполняет ход и тоже расходует ход.';
}
function authoredHint(){const o=currentObjective();if(!o)return null;const now=grid.map(row=>row.map(t=>t.color));let state=puzzleState(config);for(const move of config.solution){if(state.objectiveIndex===objectiveIndex&&state.progress===stageProgress&&JSON.stringify(state.grid)===JSON.stringify(now)&&(state.rngState|0)===(rng.getState?.()??0))return{...move,preparation:!figureMatch(applyMoves(grid,[move]),o).ids.length};state=simulatePuzzle(state,move,config)}return puzzleHint(grid,o,2)}
function capture(){return{modern:config.modern?{extra:structuredClone(mExtra),pins:mPins.slice(),progress:mProgress.slice(),bombUsed:mBombUsed,bombsMade:mBombsMade,bombs:grid.map(row=>row.map(t=>!!t.bomb))}:null,colors:grid.map(row=>row.map(t=>t.color)),score,terrain:terrain.slice(),locked,key,movesLeft,collected,turns,tools:{...tools},revision:14,objectiveIndex,stageProgress,rngState:rng.getState?.()}}
function saveCampaign(){try{localStorage.setItem(TEST_MODE?'sdvig-v14-sandbox':'sdvig-campaign-v14',JSON.stringify({unlocked,completed,current:config.id,roadPosition,pendingRoadMove,board:capture()}))}catch{}}
function ruleText(){if(config.modern)return modernRules();if(config.authored){const o=currentObjective();if(!o)return 'Все фигуры собраны';return objectiveText(o)+' · Исчезают только фигуры текущего задания. '+(o.shape==='square'?'':o.shape==='line'?'Линия — четыре желейки; горизонтально или вертикально. ':'Уголок — пять желеек, по три вдоль каждой стороны. Можно поворачивать. ')+(o.anchor?'Собери фигуру внутри золотой отметки. ':'')+(o.simultaneous?'Обе фигуры должны появиться одновременно, без общих клеток. ':'')+'Свободно сдвигай целый ряд на любое расстояние. Поле замыкается через край.'}const rules=[];if(config.glass.some(Boolean))rules.push('Разбей всё стекло: квадрат над клеткой снимает слой');else if(config.color!==null)rules.push('Собери '+config.goal+' '+['розовых','голубых','жёлтых','фиолетовых','зелёных'][config.color]+' желеек');else rules.push('Собери '+config.goal+' квадрата 2 × 2');if(locked)rules.push('Ряд 5 закрыт: собери квадрат на клетке с ключом');if(config.pair)rules.push((config.pair.axis==='x'?'Ряды':'Столбцы')+' 2 и 5 '+(config.pair.mode==='same'?'движутся вместе':'движутся навстречу'));if(config.tide)rules.push('Прилив сдвигает '+(config.tide.axis==='x'?'ряд':'столбец')+' 3 каждый третий ход');return rules.join(' · ')}
function endTurn(){if(finished)return;const won=(config.modern?C.won(modernState(),config):config.authored?objectiveIndex>=config.objectives.length:(config.glass.some(Boolean)?terrain.every(v=>v===0):collected>=config.goal))&&!locked;if(won||movesLeft<=0){finished=true;activeTool=null;if(won){completed[config.id]=Math.max(completed[config.id]||0,(config.authored||config.modern)?(turns<=config.solution.length?3:turns===config.solution.length+1?2:1):movesLeft>=config.moves*.5?3:movesLeft>=config.moves*.2?2:1);const advancement=advanceRoad({unlocked},config.id);unlocked=advancement.unlocked;if(advancement.move)pendingRoadMove=advancement.move}saveCampaign();$('#result-title').textContent=won?'Получилось!':'Ещё одна попытка?';$('#result-text').textContent=won?'Уровень '+config.id+' пройден · '+('★'.repeat(completed[config.id])):'Ходы закончились. Попробуй другой порядок сдвигов.';$('#result-action').textContent=won?'Дальше по дорожке':'Попробовать снова';$('#result-action').onclick=()=>{$('#result-dialog').close();if(won)openJourney();else startLevel(config.id)};$('#result-dialog').showModal();updateControls();return}saveCampaign()}
function finishMove(){if(config.modern){endTurn();return}if(tidePending){tidePending=false;const t=config.tide;drag={axis:t.axis,r:t.index,c:t.index,offset:0,velocity:0,tide:true};beginSettle(drag,1,true);hint('Лунный прилив: дополнительный сдвиг.','☾');return}endTurn()}
function startLevel(id,restore=null){config=level(id);document.documentElement.dataset.modern=String(!!config.modern);mExtra=config.modern?{turn:0,tides:0,routeSide:config.routeSide||-1,detourUses:0,portalUses:0,switchCount:0,beacon:0,litTurn:-1,runes:config.runes.map(r=>({...r}))}:{};modernPlayback=null;mPins=config.pins?.slice()||[];mProgress=[0,0,0,0,0];mBombUsed=mBombsMade=0;applyWorld(config.chapter);rng=seeded(config.seed+77);objectiveIndex=stageProgress=0;stageComplete=false;terrain=config.glass.slice();locked=config.lockRow!==null;key=config.key;movesLeft=config.moves;collected=turns=0;tools=(config.authored||config.modern)?{hammer:0,nova:0}:{hammer:1,nova:1};activeTool=null;finished=false;tidePending=false;reset();if(restore&&(restore.revision===14||(config.authored&&[12,13].includes(restore.revision)))&&restore.colors?.length===6&&restore.colors.every(r=>r.length===6&&r.every(c=>Number.isInteger(c)&&c>=0&&c<5))&&restore.movesLeft>0){clearAnimation();grid=restore.colors.map(row=>row.map(c=>tile(c)));if(config.modern&&restore.modern){const m=restore.modern;mExtra=m.extra||mExtra;mPins=m.pins.slice();mProgress=m.progress.slice();mBombUsed=m.bombUsed||0;mBombsMade=m.bombsMade||0;grid.forEach((row,r)=>row.forEach((t,c)=>t.bomb=!!m.bombs?.[r]?.[c]));}terrain=restore.terrain?.length===36?restore.terrain.slice():terrain;locked=!!restore.locked;key=restore.key;movesLeft=restore.movesLeft;collected=restore.collected||0;turns=restore.turns||0;tools=restore.tools||tools;score=restore.score||0;objectiveIndex=restore.objectiveIndex||0;stageProgress=restore.stageProgress||0;if(Number.isInteger(restore.rngState))rng.setState(restore.rngState);if(config.authored&&currentObjective()&&figureMatch(grid,currentObjective()).ids.length){busy=true;resolve()}else{updateControls();endTurn()}}saveCampaign();if(!TEST_MODE&&!restore&&(config.lesson||[4,6,8,11,13,15].includes(config.id))){let seen=[];try{seen=JSON.parse(localStorage.getItem('sdvig-seen-rules-v2')||'[]')}catch{}if(!seen.includes(config.id)){$('#help-dialog').showModal();try{localStorage.setItem('sdvig-seen-rules-v2',JSON.stringify([...seen,config.id]))}catch{}}}}
function remember(){history.push(capture());if(history.length>20)history.shift()}
function hint(text=null,symbol='↔'){$('#instruction').textContent=symbol+'  '+(text||(config.modern?'Сдвигай ряды. У каждого цвета своя фигура.':config.authored?'Собери фигуру по образцу. Ряды сдвигаются свободно.':'Сдвигай ряды. Собирай квадраты 2 × 2.'))}
function resize(){
 const rect=canvas.getBoundingClientRect();if(rect.width<=0)return;
 size=rect.width;step=size/N;dpr=Math.min(devicePixelRatio||1,2);
 canvas.width=Math.round(size*dpr);canvas.height=Math.round(size*dpr);
 if(drag&&!drag.settling)release(true);
}
new ResizeObserver(resize).observe(canvas);
function toast(text,ms=900){$('#combo').textContent=text;$('#combo').classList.add('show');toastUntil=time+ms}
function clearAnimation(){particles.length=ripples.length=hardwareFX.length=0;drag=null;phase=null;busy=false;toastUntil=0;$('#combo').classList.remove('show');$('#combo').textContent=''}
function drop(t,from,delay=0){const ms=duration(Math.min(410,270+Math.abs(from)*28));t.fall={from,start:time+delay,duration:ms};return delay+ms}
function reset(){
 clearAnimation();score=0;history=[];
 grid=initial(config).map(row=>row.map(t=>({...tile(t.color),bomb:!!t.bomb})));
 let end=0;
 for(let r=0;r<N;r++)for(let c=0;c<N;c++)end=Math.max(end,drop(grid[r][c],-(N-r)*.35,reduced?0:c*12+r*9));
 phase={kind:'fall',start:time,end:time+end,check:false,chain:0};busy=true;
 setPaused(false);hint();updateControls();
}
function tone(freq=400,dur=.12,vol=.04){
 if(!sound)return;
 try{audio??=new(window.AudioContext||window.webkitAudioContext)();audio.resume();
  for(let k=0;k<2;k++){const o=audio.createOscillator(),g=audio.createGain();o.type='sine';
   o.frequency.setValueAtTime(freq*(k?1.5:1),audio.currentTime);o.frequency.exponentialRampToValueAtTime(freq*.7,audio.currentTime+dur);
   g.gain.setValueAtTime(vol/(k+1),audio.currentTime);g.gain.exponentialRampToValueAtTime(.0001,audio.currentTime+dur);
   o.connect(g);g.connect(audio.destination);o.start();o.stop(audio.currentTime+dur);
  }
 }catch{}
}
function components(match){
 const unseen=new Set(match.ids),result=[];
 while(unseen.size){const first=unseen.values().next().value,ids=[],todo=[first],color=grid[Math.floor(first/N)][first%N].color;unseen.delete(first);
  while(todo.length){const i=todo.pop(),r=Math.floor(i/N),c=i%N;ids.push(i);
   for(const [nr,nc] of [[r-1,c],[r+1,c],[r,c-1],[r,c+1]]){const j=nr*N+nc;if(nr>=0&&nr<N&&nc>=0&&nc<N&&unseen.has(j)&&grid[nr][nc].color===color){unseen.delete(j);todo.push(j)}}
  }
  result.push({ids,color,x:ids.reduce((s,i)=>s+i%N+.5,0)/ids.length,y:ids.reduce((s,i)=>s+Math.floor(i/N)+.5,0)/ids.length});
 }
 return result;
}
function resolve(chain=1){
 if(config.modern){playModernStep();return}
 const match=config.modern?C.plan(modernState(),config):config.authored?figureMatch(grid,currentObjective()):squares(grid);
 if(!match.ids.length){busy=false;phase=null;updateControls();finishMove();return}
 if(config.modern){beginModernPop(match,chain);return}
 const groups=components(match);busy=true;
 for(const group of groups)for(const i of group.ids){const r=Math.floor(i/N),c=i%N;grid[r][c].pop={start:time,x:group.x-(c+.5),y:group.y-(r+.5),sad:!!terrain[i]}}
 phase={kind:'pop',start:time,chain,match,groups,burst:false};
 tone(460+chain*80,.13,.035);updateControls();
}
function burst(group){
 const {x,y,color}=group,count=reduced?4:15;
 ripples.push({x,y,color,start:time,duration:duration(370)});
 for(let i=0;i<count;i++){
  const a=i/count*Math.PI*2+(Math.random()-.5)*.3,speed=1.0+Math.random()*1.9;
  particles.push({x,y,color,vx:Math.cos(a)*speed,vy:Math.sin(a)*speed-.5,start:time,duration:duration(350+Math.random()*200),radius:.035+Math.random()*.025,angle:a,spark:i%5===0});
 }
}
function burstGlass(ids){
 for(const i of new Set(ids))if(terrain[i]){
  const final=terrain[i]===1,count=reduced?2:final?7:3,x=i%N+.5,y=Math.floor(i/N)+.5;
  for(let k=0;k<count;k++){
   const angle=k/count*Math.PI*2+(Math.random()-.5)*.4,speed=(final?1.0:.45)+Math.random()*(final?1.6:.7);
   particles.push({glass:true,sprite:k%glassShards.length,x,y,color:0,vx:Math.cos(angle)*speed,vy:Math.sin(angle)*speed-.6,start:time,duration:duration(final?460+Math.random()*150:300+Math.random()*90),radius:(final?.10:.045)+Math.random()*(final?.08:.035),angle,spin:(Math.random()-.5)*6});
  }
 }
}
function refill(p){
 const next=config.modern?{grid:p.modernEvent.after.grid.map(row=>row.map(t=>({...tile(t.color),bomb:!!t.bomb}))),falls:p.modernEvent.after.falls}:collapse(grid,p.match.ids,()=>tile());grid=next.grid;let end=0;
 for(const f of next.falls){const t=grid[f.r][f.c];t.pop=null;end=Math.max(end,drop(t,f.from,reduced?0:(f.c*11+(f.fresh?(f.missing-f.r)*24:(N-f.r)*7))))}
 phase={kind:'fall',start:time,end:time+end,check:true,chain:p.chain};updateControls();
}
function beginSettle(d,n,demo=false){
 d.n=n;d.from=d.offset;d.target=n;d.start=time;d.duration=duration(demo?300:160+Math.abs(d.target-d.offset)*42);d.settling=true;d.demo=demo;
 busy=true;if(n%N&&!d.tide){remember();if(config.modern)modernPlayback=C.simulate(modernState(),{axis:d.axis,index:d.axis==='x'?d.r:d.c,n},config,true);movesLeft--;turns++;activeTool=null;tidePending=!config.modern&&!!config.tide&&turns%3===0}updateControls();
}
function point(e){const b=canvas.getBoundingClientRect();return{x:e.clientX-b.left,y:e.clientY-b.top}}
canvas.addEventListener('pointerdown',e=>{
 if(!ready||paused||busy||finished||e.button>0)return;
 const p=point(e);selected={r:Math.min(N-1,Math.max(0,Math.floor(p.y/step))),c:Math.min(N-1,Math.max(0,Math.floor(p.x/step)))};
 if(activeTool){useTool(selected.r*N+selected.c);return}
 drag={startX:p.x,startY:p.y,r:selected.r,c:selected.c,axis:null,offset:0,velocity:0,lastOffset:0,lastEvent:e.timeStamp};
 canvas.setPointerCapture(e.pointerId);canvas.focus({preventScroll:true});tone(280,.045,.01);
});
canvas.addEventListener('pointermove',e=>{
 if(!drag||drag.settling||paused)return;
 const p=point(e),dx=p.x-drag.startX,dy=p.y-drag.startY;
 if(!drag.axis&&Math.hypot(dx,dy)>5)drag.axis=Math.abs(dx)>Math.abs(dy)?'x':'y';
 if(drag.axis&&locked&&drag.axis==='x'&&drag.r===config.lockRow){hint('Сначала собери фигуру на ключе.','⚿');drag.axis=null;return}
 if(drag.axis&&config.modern&&!lineMoves(config,drag.axis,drag.axis==='x'?drag.r:drag.c,1,locked).length){hint('Сейчас разрешена '+(config.compass?(turns%2?'вертикаль.':'горизонталь.'):'другая линия.'));drag.axis=null;return}
 if(drag.axis){const rawOffset=(drag.axis==='x'?dx:dy)/step,offset=config.singleStep?Math.max(-1,Math.min(1,rawOffset)):rawOffset,ms=Math.max(8,e.timeStamp-drag.lastEvent);
  drag.velocity=drag.velocity*.5+(offset-drag.lastOffset)/ms*.5;
  drag.offset=offset;drag.lastOffset=offset;drag.lastEvent=e.timeStamp;
 }
});
function release(cancel=false){
 if(!drag||drag.settling)return;
 if(!drag.axis){if(cancel){drag=null;return}if(config.modern&&grid[drag.r][drag.c].bomb){const i=drag.r*N+drag.c;drag=null;activateModernBomb(i);return}grid[drag.r][drag.c].tap=time;tone(350+grid[drag.r][drag.c].color*80,.09,.02);drag=null;return}
 let n=cancel?0:Math.max(-N,Math.min(N,Math.round(drag.offset)));
 if(!cancel&&Math.abs(drag.offset)>.2&&Math.abs(drag.velocity)>.008&&Math.abs(n)<Math.abs(drag.offset))n+=Math.sign(drag.velocity);
 n=Math.max(-N,Math.min(N,n));if(config.singleStep&&n)n=Math.sign(n);if(!lineMoves(config,drag.axis,drag.axis==='x'?drag.r:drag.c,n,locked).length){n=0;hint('Сдвиг недоступен: проверь цепь, компас и длину шага.','⚿')}beginSettle(drag,n);if(n%N)hint();
}
canvas.addEventListener('pointerup',()=>release());canvas.addEventListener('pointercancel',()=>release(true));
canvas.addEventListener('lostpointercapture',()=>{if(drag&&!drag.settling)release(true)});
canvas.addEventListener('keydown',e=>{
 if(e.key==='Escape'){e.preventDefault();setPaused(!paused);return}
 const dirs={ArrowLeft:['x',-1],ArrowRight:['x',1],ArrowUp:['y',-1],ArrowDown:['y',1]};
 if(!dirs[e.key]||!ready||busy||paused||finished)return;
 e.preventDefault();const [axis,n]=dirs[e.key];if(!lineMoves(config,axis,axis==='x'?selected.r:selected.c,n,locked).length){hint('Сдвиг недоступен: проверь цепь, компас и длину шага.','⚿');return}drag={axis,r:selected.r,c:selected.c,offset:0,velocity:0};beginSettle(drag,n);hint();
});
$('#undo').onclick=()=>{
 if(busy||paused||!history.length)return;
 const previous=history.pop();finished=false;$('#result-dialog').close();modernPlayback=null;clearAnimation();grid=previous.colors.map(row=>row.map(color=>tile(color)));if(config.modern&&previous.modern){mExtra=previous.modern.extra||{};mPins=previous.modern.pins.slice();mProgress=previous.modern.progress.slice();mBombUsed=previous.modern.bombUsed;mBombsMade=previous.modern.bombsMade;grid.forEach((row,r)=>row.forEach((t,c)=>t.bomb=previous.modern.bombs[r][c]));}score=previous.score;terrain=previous.terrain;locked=previous.locked;key=previous.key;movesLeft=previous.movesLeft;collected=previous.collected;turns=previous.turns;tools=previous.tools;objectiveIndex=previous.objectiveIndex||0;stageProgress=previous.stageProgress||0;stageComplete=false;if(Number.isInteger(previous.rngState))rng.setState(previous.rngState);tidePending=false;
 grid.flat().forEach(t=>t.tap=time);tone(400,.1,.025);updateControls();hint('Последний ход отменён.','↶');
};
$('#reset').onclick=()=>{if(ready&&!paused){startLevel(config.id);tone(450,.13,.025)}};
$('#burst').onclick=()=>{
 if(!ready||busy||paused||finished)return;const move=config.modern?modernHint():config.authored?authoredHint():legalHint(grid,config,locked);if(!move){toast('Попробуй подготовительный сдвиг',1400);return}
 if(move.bomb!=null){activateModernBomb(move.bomb);return}
 selected={r:move.axis==='x'?move.index:2,c:move.axis==='y'?move.index:2};
 drag={axis:move.axis,r:selected.r,c:selected.c,offset:0,velocity:0};beginSettle(drag,move.n,true);hint(move.preparation?'Подготовительный сдвиг для нужной фигуры.':'Сдвиг собирает фигуру текущего задания.','✦');
};
function setPaused(value){
 if(value&&drag&&!drag.settling)release(true);
 paused=value;$('#pause img').src=value?'assets/play.svg':'assets/pause.svg';last=performance.now();$('#paused').hidden=!value;
 $('#pause').setAttribute('aria-pressed',String(value));$('#pause').setAttribute('aria-label',value?'Продолжить':'Пауза');
 if(value&&audio?.state==='running')audio.suspend();if(!value&&sound)audio?.resume().catch(()=>{});updateControls();
}
$('#pause').onclick=()=>setPaused(!paused);$('#resume').onclick=()=>setPaused(false);
function soundUi(){$('#sound').setAttribute('aria-pressed',String(sound));$('#sound').setAttribute('aria-label',sound?'Выключить звук':'Включить звук');$('#sound-image').src='assets/sound-'+(sound?'on':'off')+'.svg'}
$('#sound').onclick=()=>{sound=!sound;try{localStorage.setItem('sdvig-sound',String(sound))}catch{}soundUi();tone(650,.15,.025);if(!sound)audio?.suspend()};
document.addEventListener('visibilitychange',()=>{if(document.hidden)setPaused(true)});
function tick(elapsed){
 time+=elapsed;
 if(toastUntil&&time>toastUntil){$('#combo').classList.remove('show');toastUntil=0}
 if(drag?.settling){const d=drag;d.offset=settle(d.from,d.target,time-d.start,d.duration);
  if(time-d.start>=d.duration){grid=applyMoves(grid,d.tide?[{axis:d.axis,index:d.axis==='x'?d.r:d.c,n:d.n}]:lineMoves(config,d.axis,d.axis==='x'?d.r:d.c,d.n,locked));
   for(let k=0;k<N;k++){const t=d.axis==='x'?grid[d.r][k]:grid[k][d.c];t.land=time;t.landAxis=d.axis}
   drag=null;tone(340,.065,.02);if(d.n%N)resolve();else{busy=false;phase=null;updateControls()}
  }
 }
 if(phase?.kind==='portal'){const p=phase,age=time-p.start;if(!p.swapped&&age>=duration(180)){p.swapped=true;grid=p.event.after.grid.map(row=>row.map(t=>({...tile(t.color),bomb:!!t.bomb})));syncModern(p.event.after);for(const i of p.event.cells)ripples.push({x:i%N+.5,y:Math.floor(i/N)+.5,color:3,start:time,duration:duration(650)});}if(age>=duration(420)){phase=null;playModernStep();}}
 if(phase?.kind==='pop'){
  const p=phase,age=time-p.start,scale=reduced ? .35 : 1;
  if(!p.burst&&age>=POP_BURST*scale){p.burst=true;p.groups.forEach(burst);if(config.modern)commitModernPop(p);score+=p.match.groups.length;if(config.authored){stageProgress+=p.match.groups.length;stageComplete=stageProgress>=(currentObjective()?.count||1)}collected+=config.color===null?p.match.groups.length:p.match.ids.filter(i=>grid[Math.floor(i/N)][i%N].color===config.color).length;burstGlass(p.match.ids);if(!config.modern)terrain=damage(terrain,p.match.ids);if(!config.modern&&locked&&p.match.ids.includes(key)){locked=false;key=null;toast('Замок открыт!',1000)}best=Math.max(best,p.chain);
   try{localStorage.setItem('sdvig-best',best)}catch{}
   if(p.chain>1)toast(p.chain>=3?'Желейная волна ×'+p.chain:'Каскад ×'+p.chain);updateControls();
  }
  if(age>=POP_DURATION*scale)refill(p);
 }else if(phase?.kind==='fall'&&time>=phase.end){
  const p=phase;for(const row of grid)for(const t of row)t.fall=null;
  if(p.check&&config.authored&&stageComplete){objectiveIndex++;stageProgress=0;stageComplete=false;phase=null;busy=true;if(currentObjective())toast('Следующая фигура',1000);updateControls();hint();resolve(1)}else if(p.check&&(config.modern||p.chain<30))resolve(p.chain+1);else{phase=null;busy=false;updateControls();if(p.check)finishMove()}
 }
 for(let i=particles.length-1;i>=0;i--)if(time-particles[i].start>=particles[i].duration)particles.splice(i,1);
 for(let i=ripples.length-1;i>=0;i--)if(time-ripples[i].start>=ripples[i].duration)ripples.splice(i,1);
}
function drawTile(t,x,y,sx=1,sy=1,sad=false,tilt=0){
 let scale=1,alpha=1;
 if(!reduced&&!t.pop&&!t.fall){const breath=Math.sin(time*.0024+(t.wiggle||0)),wobble=Math.sin(time*.00135+(t.wiggle||0));sx*=1+breath*.018;sy*=1-breath*.015;tilt+=wobble*.017;}
 if(reduced)tilt=0;
 if(t.fall){const f=t.fall,age=time-f.start,pose=fallPose(f.from,age,f.duration);y+=pose.y;sx*=pose.sx;sy*=pose.sy}
 if(t.pop){const p=popPose((time-t.pop.start)/(reduced ? .35 : 1));scale=p.scale;sx*=p.sx;sy*=p.sy;x+=t.pop.x*p.pull;y+=t.pop.y*p.pull;alpha=p.alpha}
 const age=time-t.land;if(age>=0&&age<150&&!reduced){const wave=Math.sin(age/150*Math.PI)*(1-age/150)*.105;if(t.landAxis==='x'){sx*=1-wave;sy*=1+wave*.65}else{sy*=1-wave;sx*=1+wave*.65}}
 const tap=time-t.tap;if(tap>=0&&tap<170&&!reduced){const p=Math.sin(tap/170*Math.PI)*.055;sx*=1+p;sy*=1-p}
 if(scale<.005||alpha<=0)return;
 const w=step*.96;ctx.save();ctx.translate(x*step,y*step);ctx.rotate(tilt);ctx.scale(sx*scale,sy*scale);ctx.globalAlpha=alpha;
 ctx.drawImage((sad||t.pop?.sad?sadSprites:sprites)[t.color],-w/2,-w/2,w,w);if(t.bomb){const b=mechanicArt[0],h=w*.78,bw=h*b.width/b.height;ctx.drawImage(b,-bw/2,-h/2,bw,h)}ctx.restore();
}
function drawEffects(){
 if(phase?.kind==='portal'){const p=clamp01((time-phase.start)/duration(420)),[a,b]=phase.event.cells,ax=(a%6+.5)*step,ay=(Math.floor(a/6)+.5)*step,bx=(b%6+.5)*step,by=(Math.floor(b/6)+.5)*step,cx=(ax+bx)/2,cy=Math.min(ay,by)-step*.4;ctx.save();ctx.globalAlpha=Math.sin(p*Math.PI)*.8;ctx.strokeStyle='#e7c6ff';ctx.shadowColor='#b888ff';ctx.shadowBlur=step*.12;ctx.lineWidth=step*.04;ctx.beginPath();ctx.moveTo(ax,ay);ctx.quadraticCurveTo(cx,cy,bx,by);ctx.stroke();for(const t of [p,1-p]){const q=1-t,x=q*q*ax+2*q*t*cx+t*t*bx,y=q*q*ay+2*q*t*cy+t*t*by;ctx.fillStyle='#fff5c9';ctx.beginPath();ctx.arc(x,y,step*.065,0,Math.PI*2);ctx.fill();}ctx.restore();}

 for(let i=hardwareFX.length-1;i>=0;i--){const fx=hardwareFX[i],p=clamp01((time-fx.start)/duration(650));if(p>=1){hardwareFX.splice(i,1);continue;}const im=lockArt[fx.kind],h=step*.7,w=h*im.width/im.height;ctx.save();ctx.globalAlpha=(1-p)**1.4;ctx.translate(fx.x*step,(fx.y-p*.5)*step);ctx.rotate(Math.sin(p*Math.PI)*.18);ctx.shadowColor='#ffe5a8';ctx.shadowBlur=step*.12;ctx.drawImage(im,-w/2,-h/2,w,h);ctx.restore();}

 for(const ripple of ripples){const p=clamp01((time-ripple.start)/ripple.duration),x=ripple.x*step,y=ripple.y*step,r=step*(.25+easeOut(p)*.85);
  ctx.save();ctx.globalAlpha=(1-p)*.55;const g=ctx.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,'#fff8');g.addColorStop(.25,colors[ripple.color]+'55');g.addColorStop(1,colors[ripple.color]+'00');ctx.fillStyle=g;ctx.beginPath();ctx.arc(x,y,r,0,7);ctx.fill();
  ctx.globalAlpha=(1-p)*.65;ctx.strokeStyle=colors[ripple.color];ctx.lineWidth=(1-p)*step*.028;ctx.beginPath();ctx.arc(x,y,r*(.65+.25*p),0,7);ctx.stroke();ctx.restore();
 }
 for(const p of particles){const u=clamp01((time-p.start)/p.duration),t=(time-p.start)/1000;
  const x=(p.x+p.vx*t)*step,y=(p.y+p.vy*t+1.8*t*t)*step,s=p.radius*step*(1-u*.65);
  ctx.save();ctx.globalAlpha=(1-u)**1.3;ctx.translate(x,y);ctx.rotate(p.angle+u*(p.glass?p.spin:.7));ctx.fillStyle=colors[p.color];
  if(p.glass){const shard=glassShards[p.sprite],w=s*2;ctx.drawImage(shard,-w/2,-w/2,w,w)}
  else if(p.spark){ctx.fillStyle='#fff';ctx.beginPath();ctx.moveTo(-s*1.6,0);ctx.quadraticCurveTo(-s*.2,-s*.2,0,-s*1.6);ctx.quadraticCurveTo(s*.2,-s*.2,s*1.6,0);ctx.quadraticCurveTo(s*.2,s*.2,0,s*1.6);ctx.quadraticCurveTo(-s*.2,s*.2,-s*1.6,0);ctx.fill()}
  else{ctx.beginPath();ctx.ellipse(0,0,s*1.3,s,0,0,7);ctx.fill();ctx.fillStyle='#fff9';ctx.beginPath();ctx.ellipse(-s*.25,-s*.3,s*.38,s*.2,-.4,0,7);ctx.fill()}
  ctx.restore();
 }
}
function activeTracks(){if(!config.modern||!drag?.axis)return[];const lines=drag.tide?[{axis:drag.axis,index:drag.axis==='x'?drag.r:drag.c,n:drag.n||1}]:lineMoves(config,drag.axis,drag.axis==='x'?drag.r:drag.c,drag.n||1,locked);return lines.map(m=>({...m,...C.route({pins:mPins,routeSide:mExtra.routeSide},config,m.axis,m.index)}));}
function drawRoutePreview(){
 if(!config.modern||!drag?.axis)return;
 for(const track of activeTracks()){ctx.save();ctx.strokeStyle='#ffe7a8';ctx.lineWidth=step*.025;ctx.globalAlpha=.7;ctx.setLineDash([step*.09,step*.07]);for(let k=0;k<track.cells.length;k++){const a=track.cells[k],b=track.cells[(k+1)%track.cells.length],ax=a%6+.5,ay=Math.floor(a/6)+.5,bx=b%6+.5,by=Math.floor(b/6)+.5;if(Math.abs(ax-bx)>3||Math.abs(ay-by)>3)continue;ctx.beginPath();ctx.moveTo(ax*step,ay*step);ctx.lineTo(bx*step,by*step);ctx.stroke();}ctx.setLineDash([]);ctx.globalAlpha=.4;for(const i of track.cells){ctx.beginPath();ctx.roundRect((i%6+.08)*step,(Math.floor(i/6)+.08)*step,step*.84,step*.84,step*.12);ctx.stroke();}ctx.restore();}
}
function drawJellies(sad=false){
 const tracks=activeTracks();
 for(let r=0;r<N;r++)for(let c=0;c<N;c++){
 let x=c+.5,y=r+.5;const cell=r*N+c;
 if(config.modern&&drag?.axis){
 const track=tracks.find(t=>t.cells.includes(cell));
 if(track){const primary=drag.axis==='x'?drag.r:drag.c,offset=drag.offset*(track.index===primary?1:(config.pair?.mode==='opposite'?-1:1)),free=track.cells,at=free.indexOf(cell),f=at+offset,base=Math.floor(f),part=f-base,a=free[((base%free.length)+free.length)%free.length],b=free[(((base+1)%free.length)+free.length)%free.length];
 let dx=b%6-a%6,dy=Math.floor(b/6)-Math.floor(a/6);if(dx>3)dx-=6;if(dx< -3)dx+=6;if(dy>3)dy-=6;if(dy< -3)dy+=6;
 x=a%6+.5+dx*part;y=Math.floor(a/6)+.5+dy*part;
 // Old fixed-pin levels retain their rules, but travel visibly arcs around pins.
 if(!config.detour&&(Math.abs(dx)>1||Math.abs(dy)>1)){if(track.axis==='x')y-=Math.sin(part*Math.PI)*.62;else x-=Math.sin(part*Math.PI)*.62;}
 const pull=reduced?0:Math.min(.17,Math.abs(drag.velocity||0)*9+Math.abs(Math.sin(offset*Math.PI))*.045),horizontal=Math.abs(dx)>=Math.abs(dy),sx=horizontal?1+pull:1-pull*.5,sy=horizontal?1-pull*.5:1+pull,tilt=reduced?0:Math.sign(offset)*Math.sin(part*Math.PI)*.075;
 const xs=x<.5?[0,6]:x>5.5?[0,-6]:[0],ys=y<.5?[0,6]:y>5.5?[0,-6]:[0];for(const ox of xs)for(const oy of ys)drawTile(grid[r][c],x+ox,y+oy,sx,sy,sad,tilt);continue;}
 drawTile(grid[r][c],x,y,1,1,sad);continue;
 }
 const moving=drag?.axis?(drag.tide?[{axis:drag.axis,index:drag.axis==='x'?drag.r:drag.c,n:1}]:lineMoves(config,drag.axis,drag.axis==='x'?drag.r:drag.c,1,locked)):[],motion=moving.find(m=>m.axis==='x'?r===m.index:c===m.index),offset=drag?drag.offset*(motion?.n||1):0;
 if(motion){const stretch=reduced?0:Math.min(.16,Math.abs(drag.velocity||0)*9+Math.abs(Math.sin(offset*Math.PI))*.04),sx=drag.axis==='x'?1+stretch:1-stretch*.5,sy=drag.axis==='y'?1+stretch:1-stretch*.5;if(drag.axis==='x'){x=((x+offset)%N+N)%N;for(const d of [-N,0,N])drawTile(grid[r][c],x+d,y,sx,sy,sad)}else{y=((y+offset)%N+N)%N;for(const d of [-N,0,N])drawTile(grid[r][c],x,y+d,sx,sy,sad)}}else drawTile(grid[r][c],x,y,1,1,sad);
 }
}
function drawGlassJellies(){
 // Masks belong to fixed cells, not moving jelly identities. Cache until glass or size changes.
 if(!glassMasks||glassMasks.terrain!==terrain||glassMasks.size!==size){
  const covered=new Path2D(),free=new Path2D();free.rect(0,0,size,size);let count=0;
  for(let i=0;i<N*N;i++)if(terrain[i]){const x=i%N*step,y=Math.floor(i/N)*step;covered.rect(x,y,step,step);free.rect(x,y,step,step);count++}
  glassMasks={terrain,size,covered,free,count};
 }
 if(!glassMasks.count){drawJellies();return}
 ctx.save();ctx.clip(glassMasks.free,'evenodd');drawJellies();ctx.restore();
 ctx.save();ctx.clip(glassMasks.covered);drawJellies(true);ctx.restore();
}
function render(now){
 const elapsed=Math.max(0,Math.min(1000,now-last));last=now;if($('#level-dialog').open){requestAnimationFrame(render);return}if(!paused&&ready)tick(elapsed);
 ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,size,size);
 if(ready){drawWells();ctx.save();ctx.beginPath();ctx.roundRect(0,0,size,size,step*.1);ctx.clip();
  drawRoutePreview();drawGlassJellies();drawTerrain();drawEffects();ctx.restore();
 }
 requestAnimationFrame(render);
}
let wellCache=null;
function drawWells(){
 if(!wellCache||wellCache.size!==size||wellCache.dpr!==dpr){
 const buffer=document.createElement('canvas');buffer.width=Math.round(size*dpr);buffer.height=Math.round(size*dpr);const g=buffer.getContext('2d');g.setTransform(dpr,0,0,dpr,0,0);
 for(let r=0;r<N;r++)for(let c=0;c<N;c++){const x=c*step+step*.025,y=r*step+step*.025,w=step*.95;const gradient=g.createLinearGradient(x,y,x+w,y+w);gradient.addColorStop(0,'#234954');gradient.addColorStop(.16,'#102e3c');gradient.addColorStop(1,'#0a202e');g.fillStyle=gradient;g.beginPath();g.roundRect(x,y,w,w,step*.19);g.fill();g.strokeStyle='#9cead62b';g.lineWidth=1;g.stroke();}wellCache={size,dpr,buffer};
 }
 ctx.drawImage(wellCache.buffer,0,0,size,size);
}
function drawTerrain(){ctx.save();const target=currentObjective();if(config.authored&&target?.anchor){
  // This marks the allowed area, keeping all valid rotations of the objective.
  const [r,c]=target.anchor,h=target.shape==='square'?2:3,w=h;
  const inset=step*.018,x=c*step+inset,y=r*step+inset,right=(c+w)*step-inset,bottom=(r+h)*step-inset;
  ctx.lineJoin='round';ctx.lineCap='round';ctx.strokeStyle='#041d2ddd';ctx.lineWidth=4;
  ctx.beginPath();ctx.roundRect(x,y,right-x,bottom-y,step*.08);ctx.stroke();
  ctx.strokeStyle='#a7ffeb';ctx.lineWidth=1.5;ctx.setLineDash([step*.10,step*.075]);
  ctx.stroke();ctx.setLineDash([]);
  const arm=step*.25,round=step*.055;
  for(const [cx,cy,dx,dy] of [[x,y,1,1],[right,y,-1,1],[right,bottom,-1,-1],[x,bottom,1,-1]]){
   ctx.beginPath();ctx.moveTo(cx,cy+dy*arm);ctx.lineTo(cx,cy+dy*round);ctx.quadraticCurveTo(cx,cy,cx+dx*round,cy);ctx.lineTo(cx+dx*arm,cy);
   ctx.strokeStyle='#644b27';ctx.lineWidth=5;ctx.stroke();
   const gold=ctx.createLinearGradient(cx,cy-step*.03,cx,cy+step*.2);gold.addColorStop(0,'#fff4c0');gold.addColorStop(.45,'#ffdf83');gold.addColorStop(1,'#d9a34b');
   ctx.strokeStyle=gold;ctx.lineWidth=2.7;ctx.stroke();
  }
 }
 for(let i=0;i<36;i++)if(terrain[i]){
  const x=(i%6+.02)*step,y=(Math.floor(i/6)+.02)*step,w=step*.96;
  const cracked=terrain[i]===1&&config.glass[i]>1;
  ctx.globalAlpha=cracked?.88:.8;ctx.drawImage(glassSprites[cracked?1:0],x,y,w,w);
  if(terrain[i]>1){ctx.globalAlpha=.4;ctx.drawImage(glassSprites[0],x+step*.025,y+step*.025,w-step*.05,w-step*.05)}
  ctx.globalAlpha=1;
 }

 if(config.modern){drawModernPins();drawModernOverlays();}
 if(locked)drawLockedRow();
 if(config.pair){const p=config.pair;ctx.fillStyle='#d5adff';ctx.font='bold '+step*.18+'px sans-serif';for(const i of [p.a,p.b])ctx.fillText(p.mode==='opposite'?(i===p.a?'⇢':'⇠'):'⇢',p.axis==='x'?2:i*step+2,p.axis==='x'?(i+.24)*step:step*.2)}ctx.restore()}
// Source sprites retain their alpha; dimensions below use the actual artwork bounds.
function drawLockedRow(){
 const y=(config.lockRow+.5)*step;
 ctx.save();
 const shade=ctx.createLinearGradient(0,y-step*.5,0,y+step*.5);
 shade.addColorStop(0,'#16302c00');shade.addColorStop(.5,'#15392a48');shade.addColorStop(1,'#16302c00');
 ctx.fillStyle=shade;ctx.fillRect(0,y-step*.5,size,step);
 // Two undistorted sections join behind the lock. Never stretch the links.
 const chain=lockArt[0],height=step*.22,width=height*chain.width/chain.height;
 ctx.shadowColor='#071e29cc';ctx.shadowBlur=step*.06;ctx.shadowOffsetY=step*.035;
 for(const [left,right] of [[0,size/2],[size/2,size]]){
  ctx.save();ctx.beginPath();ctx.rect(left,y-height,right-left,height*2);ctx.clip();
  for(let x=left;x<right;x+=width)ctx.drawImage(chain,x,y-height/2,width,height);
  ctx.restore();
 }
 const lock=lockArt[1],h=step*.82,w=h*lock.width/lock.height;
 ctx.drawImage(lock,(size-w)/2,y-h*.52,w,h);
 // A dark medallion separates the small gold key from every jelly colour.
 const x=(key%N+.72)*step,ky=(Math.floor(key/N)+.30)*step,r=step*.26;
 ctx.shadowOffsetY=step*.025;ctx.shadowBlur=step*.045;
 const halo=ctx.createRadialGradient(x-r*.3,ky-r*.5,0,x,ky,r);
 halo.addColorStop(0,'#316c70f5');halo.addColorStop(1,'#0c303df5');
 ctx.fillStyle=halo;ctx.beginPath();ctx.arc(x,ky,r,0,Math.PI*2);ctx.fill();
 ctx.shadowBlur=0;ctx.shadowOffsetY=0;ctx.strokeStyle='#f9dc9399';ctx.lineWidth=step*.012;ctx.stroke();
 const icon=lockArt[2],ih=step*.43,iw=ih*icon.width/icon.height;
 ctx.drawImage(icon,x-iw/2,ky-ih/2,iw,ih);
 ctx.restore();
}
function mechanicNotes(){return [
 config.detour?'Ряд огибает штифт через 3 клетки соседнего ряда. Золотой путь показывает движение.':null,
 config.portals?'Порталы меняют две желейки местами, если сдвиг затронул ровно один вход.':null,
 config.switcher!=null?'Сборка на стрелке меняет сторону объезда: сверху/слева ↔ снизу/справа.':null,
 config.lockRow!=null?'Цепь блокирует сдвиг ряда 5. Собери фигуру на ключе.':null,
 config.pair?(config.pair.axis==='x'?'Ряды':'Столбцы')+' 2 и 5 '+(config.pair.mode==='same'?'движутся вместе.':'движутся навстречу.'):null,
 config.tide?'Прилив: '+(config.tide.axis==='x'?'ряд':'столбец')+' 3 каждые '+config.tide.every+' хода.':null,
 config.runes?.length?'Печать снимается фигурой её цвета над отмеченной клеткой.':null,
 config.beacons?.length?'Маяки: собирай цвета слева направо, один маяк за ход.':null,
 config.compass?'Компас: чередуй горизонтальные и вертикальные сдвиги. Сейчас '+(turns%2?'вертикаль.':'горизонталь.'):null,
 config.singleStep?'Точный шаг: сдвиг только на одну клетку.':null].filter(Boolean)}
function drawModernOverlays(){
 if(config.portals)for(const [k,i] of config.portals.entries()){const x=(i%6+.5)*step,y=(Math.floor(i/6)+.5)*step;ctx.save();ctx.strokeStyle=k?'#ffbded':'#94f9ef';ctx.lineWidth=step*.035;ctx.shadowColor=ctx.strokeStyle;ctx.shadowBlur=step*.07;ctx.beginPath();ctx.ellipse(x,y+step*.27,step*.39,step*.15,0,0,7);ctx.stroke();ctx.drawImage(extraArt.portal,x-step*.2,y+step*.08,step*.4,step*.4);ctx.fillStyle='#fff7c9';ctx.font='bold '+step*.13+'px sans-serif';ctx.fillText(k?'B':'A',x+step*.29,y+step*.35);ctx.restore();}
 if(config.switcher!=null){const i=config.switcher,x=(i%6+.5)*step,y=(Math.floor(i/6)+.5)*step;ctx.save();ctx.drawImage(extraArt.switch,x-step*.23,y-step*.48,step*.46,step*.46);ctx.fillStyle='#ffe7a8';ctx.font='bold '+step*.19+'px sans-serif';ctx.fillText((mExtra.routeSide||-1)<0?'↑':'↓',x+step*.2,y-step*.19);ctx.restore();}
 for(const rune of mExtra.runes||[]){if(!rune.layers)continue;const x=(rune.cell%6+.5)*step,y=(Math.floor(rune.cell/6)+.5)*step;ctx.save();ctx.translate(x,y);ctx.strokeStyle=colors[rune.color];ctx.shadowColor=colors[rune.color];ctx.shadowBlur=step*.06;ctx.lineWidth=step*.035;ctx.beginPath();ctx.roundRect(-step*.43,-step*.43,step*.86,step*.86,step*.12);ctx.stroke();const im=extraArt.rune;ctx.drawImage(im,-step*.18,-step*.49,step*.36,step*.36);ctx.shadowBlur=0;ctx.fillStyle=colors[rune.color];ctx.beginPath();ctx.arc(0,-step*.31,step*.065,0,7);ctx.fill();if(rune.layers>1){ctx.fillStyle='#fff';ctx.font='bold '+step*.16+'px sans-serif';ctx.fillText('2',step*.26,-step*.21)}ctx.restore();}
 if(config.tide){const t=config.tide;ctx.save();ctx.fillStyle='#b8f4ff';ctx.font='bold '+step*.16+'px sans-serif';const label=(t.direction===-1?'−':'+')+(t.every-turns%t.every);ctx.fillText(label,t.axis==='x'?step*.04:(t.index+.06)*step,t.axis==='x'?(t.index+.92)*step:step*.94);ctx.restore();}
 if(config.compass){ctx.save();ctx.strokeStyle='#ffe7a8';ctx.lineWidth=step*.03;ctx.setLineDash([step*.08,step*.06]);ctx.strokeRect(step*.02,step*.02,size-step*.04,size-step*.04);ctx.restore();}
}
function modernState(){return{...mExtra,turn:turns,locked,grid:grid.map(row=>row.map(t=>t.bomb?{color:t.color,bomb:true}:{color:t.color})),pins:mPins.slice(),terrain:terrain.slice(),progress:mProgress.slice(),bombUsed:mBombUsed,bombsMade:mBombsMade,rngState:rng.getState()};}
function modernRules(){return 'Собирай одноцветные фигуры по образцам в заданиях. Их можно поворачивать; поле замыкается через край. '+(config.pinGoal?'Штифт удерживает желейку при сдвиге и падении. Собери её в фигуру или взорви. ':'')+(config.bombs?'Шесть желеек за сборку создают бомбу. Нажатие взрывает область 3 × 3 и тратит ход; соседние бомбы срабатывают цепью. ':'')+(config.glass.some(Boolean)?'Совпадение или взрыв снимает один слой стекла. ':'')+mechanicNotes().join(' ')}
function modernFigure(shape,color){const f=document.createElement('div'),cells=SHAPES[shape].cells;f.className='mini-figure';f.style.setProperty('--cols',Math.max(...cells.map(p=>p[1]))+1);f.style.setProperty('--rows',Math.max(...cells.map(p=>p[0]))+1);for(const [r,c] of cells){const im=document.createElement('img');im.src='assets/jelly-'+names[color]+'-opal.webp';im.alt='';im.draggable=false;im.style.gridRow=r+1;im.style.gridColumn=c+1;f.append(im)}return f;}
function drawModernGoals(){
 const signature=JSON.stringify([config.id,mProgress,mPins,terrain,mBombUsed,mBombsMade,mExtra,locked,turns]);if(signature===lastGoalSignature)return;lastGoalSignature=signature;
 document.documentElement.dataset.modern='true';
 const holder=$('#goal-pattern');holder.replaceChildren();holder.style.setProperty('--target-cols',Math.max(1,Math.min(3,config.targets.length)));
 const colorWords=['Розовые','Голубые','Жёлтые','Фиолетовые','Зелёные'];
 for(const t of config.targets){const done=mProgress[t.color]>=t.count,card=document.createElement('div');card.className='quest-card modern-quest'+(done?' complete':'');const art=document.createElement('div');art.className='quest-art';art.append(modernFigure(config.rules[t.color],t.color));const copy=document.createElement('div');copy.className='quest-copy';const title=document.createElement('b');title.textContent=colorWords[t.color];const detail=document.createElement('span');detail.className='quest-detail';detail.textContent=SHAPES[config.rules[t.color]].name;const progress=document.createElement('small');progress.className='quest-progress';progress.textContent=done?'✓':Math.min(mProgress[t.color],t.count)+' / '+t.count;copy.append(title,detail);card.append(art,copy,progress);holder.append(card)}
 const extra=document.createElement('div');extra.className='mechanic-goals';
 const badge=(asset,text,done)=>{const b=document.createElement('div');b.className='mechanic-goal'+(done?' complete':'');const im=document.createElement('img');im.src='assets/'+asset+(['rune-opal','portal-opal','switch-opal'].includes(asset)?'.svg':'.webp');im.alt='';const label=document.createElement('span');label.textContent=text;b.append(im,label);extra.append(b)};
 if(config.pinGoal)badge('pin-opal','Крепления: '+(config.pins.length-mPins.length)+' / '+config.pins.length,!mPins.length);
 if(config.bombGoal)badge('bomb-opal','Взорвать: '+Math.min(mBombUsed,config.bombGoal)+' / '+config.bombGoal,mBombUsed>=config.bombGoal);
 if(config.glass.some(Boolean))badge('tile-glass-cracked','Стекло: '+terrain.reduce((a,b)=>a+b,0)+' слоёв',terrain.every(v=>v===0));
 if(config.detourGoal)badge('pin-opal','Объезд: '+Math.min(mExtra.detourUses||0,config.detourGoal)+' / '+config.detourGoal,(mExtra.detourUses||0)>=config.detourGoal);
 if(config.portalGoal)badge('portal-opal','Переход: '+Math.min(mExtra.portalUses||0,config.portalGoal)+' / '+config.portalGoal,(mExtra.portalUses||0)>=config.portalGoal);
 if(config.switchGoal)badge('switch-opal','Развилка: '+Math.min(mExtra.switchCount||0,config.switchGoal)+' / '+config.switchGoal,(mExtra.switchCount||0)>=config.switchGoal);
 if(config.tideGoal)badge('rune-opal','Приливы: '+(mExtra.tides||0)+' / '+config.tideGoal,(mExtra.tides||0)>=config.tideGoal);
 if(config.lockRow!=null)badge('lock-opal',locked?'Найди ключ':'Замок открыт',!locked);
 if(config.runes?.length)badge('rune-opal','Печати: '+mExtra.runes.reduce((a,r)=>a+r.layers,0)+' слоёв',mExtra.runes.every(r=>!r.layers));
 if(extra.childElementCount)holder.append(extra);
 if(config.beacons?.length){const b=document.createElement('div');b.className='beacon-strip';const heading=document.createElement('small');heading.textContent='МАЯКИ · '+(mExtra.beacon||0)+' / '+config.beacons.length;heading.className='beacon-heading';b.append(heading);b.setAttribute('aria-label','Маяки по порядку');config.beacons.forEach((color,i)=>{const el=document.createElement('span');el.className=i<(mExtra.beacon||0)?'lit':i===(mExtra.beacon||0)?'next':'';el.style.setProperty('--beacon',colors[color]);const jewel=document.createElement('img');jewel.src='assets/jelly-'+names[color]+'-opal.webp';jewel.alt=COLOR_NAMES[color];el.append(jewel);el.setAttribute('aria-label','Маяк '+(i+1)+' · '+COLOR_NAMES[color]);el.title=COLOR_NAMES[color]+(i<(mExtra.beacon||0)?' · зажжён':' · собери фигуру');b.append(el)});holder.append(b);}
 const legend=document.createElement('div');legend.className='color-legend';legend.setAttribute('aria-label','Какие фигуры собирает каждый цвет');for(let c=0;c<5;c++){const item=document.createElement('div');item.title=COLOR_NAMES[c]+' · '+SHAPES[config.rules[c]].name;item.append(modernFigure(config.rules[c],c));legend.append(item)}holder.append(legend);
 $('#goal-stage').textContent='Все цели';$('#score-label').textContent='ЖЕЛЕЙКИ';$('#rules').textContent=modernRules();$('#help-text').textContent=modernRules();
 $('#help-extra').textContent='За один ход можно зажечь только один маяк, в порядке слева направо. Взрыв не зажигает маяк и не снимает цветную печать без подходящей фигуры. Все пять цветов подчиняются образцам внизу заданий, даже если цвет не указан в цели. «Показать» выполняет один ход из проверенного решения; после своих ходов подбирает подходящий сдвиг. «Назад» восстанавливает желейки, бомбы, крепления и ходы.';
 const notes=[...mechanicNotes(),config.bombs?'6+ за сборку → бомба. Нажми, чтобы взорвать.':null,config.pinGoal?'Штифт держит желейку. Собери её, чтобы освободить.':null].filter(Boolean);$('#mechanic-notes').textContent=notes.join(' ');$('#mechanic-notes').hidden=!notes.length;
 $('#score').textContent=config.targets.reduce((a,t)=>a+Math.min(mProgress[t.color],t.count),0)+' / '+config.targets.reduce((a,t)=>a+t.count,0);
}
function drawModernPins(){const im=mechanicArt[1],h=step*.35,w=h*im.width/im.height;for(const i of mPins){const x=(i%N+.5)*step,y=(Math.floor(i/N)+.22)*step;ctx.save();ctx.shadowColor='#04222dcc';ctx.shadowBlur=step*.035;ctx.shadowOffsetY=step*.02;ctx.drawImage(im,x-w/2,y-h/2,w,h);ctx.restore();}}
function beginModernPop(match,chain=1){const groups=components(match);busy=true;for(const group of groups)for(const i of group.ids){const r=Math.floor(i/N),c=i%N;grid[r][c].pop={start:time,x:group.x-(c+.5),y:group.y-(r+.5),sad:!!terrain[i]};}phase={kind:'pop',start:time,chain,match,groups,burst:false};tone(match.detonated.length?170:460+chain*80,.16,.04);updateControls();}
function activateModernBomb(i){if(busy||paused||finished||!grid[Math.floor(i/N)]?.[i%N]?.bomb)return;remember();modernPlayback=C.simulate(modernState(),{bomb:i},config,true);movesLeft--;turns++;activeTool=null;playModernStep();hint('Опаловый взрыв очищает область 3 × 3.','✦');}
function syncModern(s){mExtra={turn:s.turn,tides:s.tides||0,routeSide:s.routeSide||-1,detourUses:s.detourUses||0,portalUses:s.portalUses||0,switchCount:s.switchCount||0,beacon:s.beacon,litTurn:s.litTurn,runes:s.runes.map(r=>({...r}))};mPins=s.pins.slice();mProgress=s.progress.slice();mBombUsed=s.bombUsed;mBombsMade=s.bombsMade;terrain=s.terrain.slice();locked=s.locked;key=locked?config.key:null;}
function playModernStep(){
 const event=modernPlayback?.events.shift();
 if(!event){if(modernPlayback){syncModern(modernPlayback.state);rng.setState(modernPlayback.state.rngState);modernPlayback=null;}busy=false;phase=null;updateControls();finishMove();return;}
 if(event.type==='portal'){phase={kind:'portal',start:time,event,swapped:false};busy=true;toast('Опаловый переход!',900);return;}
 if(event.type==='drift'){phase=null;const m=event.move;drag={axis:m.axis,r:m.index,c:m.index,offset:0,velocity:0,tide:true};beginSettle(drag,m.n,true);hint('Прилив сдвигает отмеченный ряд.','☾');return;}
 beginModernPop(event.plan);phase.modernEvent=event;
}
function commitModernPop(p){
 const previous=mExtra.beacon||0,pins=mPins.length,wasLocked=locked,oldSwitch=mExtra.switchCount||0;
 syncModern(p.modernEvent.after);
 if(p.match.reward!=null){const i=p.match.reward;grid[Math.floor(i/N)][i%N].pop=null;toast('Опаловая бомба создана!',1100);}
 if(p.match.detonated.length){toast(p.match.detonated.length>1?'Цепная реакция!':'Опаловый взрыв!',1100);for(const i of p.match.detonated)ripples.push({x:i%N+.5,y:Math.floor(i/N)+.5,color:2,start:time,duration:duration(650),blast:true});}
 else if((mExtra.switchCount||0)>oldSwitch)toast('Развилка переключена! '+((mExtra.routeSide||-1)<0?'↑ / ←':'↓ / →'),1200);
 else if(wasLocked&&!locked){hardwareFX.push({start:time,kind:1,x:3,y:config.lockRow+.5},{start:time,kind:2,x:config.key%6+.5,y:Math.floor(config.key/6)+.5});toast('Ключ найден · цепь снята!',1100);}
 else if((mExtra.beacon||0)>previous)toast('Маяк '+mExtra.beacon+' зажжён!',1000);
 else if(mPins.length<pins)toast('Крепление снято!',900);
}
let modernProofId=null,modernProof=[];
function modernKey(s){return JSON.stringify([s.grid.map(row=>row.map(t=>[t.color,!!t.bomb])),s.pins,s.terrain,s.progress,s.bombUsed,s.bombsMade,s.tides||0,s.routeSide||-1,s.detourUses||0,s.portalUses||0,s.switchCount||0,s.locked,s.beacon,s.litTurn,s.runes,s.turn,s.rngState|0])}
function modernHint(){
 const state=modernState();if(modernProofId!==config.id){modernProofId=config.id;modernProof=[];let s=C.initial(config);for(const move of config.solution){modernProof.push({key:modernKey(s),move});s=C.simulate(s,move,config)}}const exact=modernProof.find(p=>p.key===modernKey(state));if(exact)return{...exact.move,preparation:false};
 let best=null,bestScore=-Infinity;const candidates=[];for(const move of C.actions(state,config)){const s=C.simulate(state,move,config);if(C.won(s,config))return move;const score=C.heuristic(s,config);candidates.push({move,s,score});if(score>bestScore){bestScore=score;best=move}}candidates.sort((a,b)=>b.score-a.score);for(const first of candidates.slice(0,6))for(const next of C.actions(first.s,config)){const s=C.simulate(first.s,next,config);if(C.won(s,config))return{...first.move,preparation:true};const score=C.heuristic(s,config)-.05;if(score>bestScore){bestScore=score;best={...first.move,preparation:true}}}return best;
}

function useTool(i){const kind=activeTool;if(!kind||!tools[kind]||config.authored)return;remember();tools[kind]--;activeTool=null;movesLeft--;turns++;tidePending=!config.modern&&!!config.tide&&turns%3===0;const r=Math.floor(i/6),c=i%6,ids=kind==='hammer'?[i]:Array.from({length:36},(_,j)=>j).filter(j=>Math.floor(j/6)===r||j%6===c);const match={ids,groups:[]};for(const j of ids)grid[Math.floor(j/6)][j%6].pop={start:time,x:0,y:0,sad:!!terrain[j]};phase={kind:'pop',start:time,chain:1,match,groups:components(match),burst:false};busy=true;hint(kind==='hammer'?'Луч снимает слой стекла с одной клетки.':'Нова очищает строку и столбец.','✧');updateControls()}
for(const name of ['hammer','nova'])$('#'+name).onclick=()=>{activeTool=activeTool===name?null:name;hint(activeTool?'Выбери клетку на поле. Бустер расходует ход.':'Сдвигай ряды. Собирай квадраты 2 × 2.',activeTool?'✧':'↔');updateControls()};
$('#help').onclick=()=>{if(ready&&!busy)$('#help-dialog').showModal()};$('#close-help').onclick=()=>$('#help-dialog').close();
let worldMap=null,worldDisabled=false;
let mapChapter=config.chapter,selectedRoadLevel=config.id,mapMoving=false,roadAnimation=0;
let appliedWorldImage=null;
function applyWorld(chapter){const w=worldForChapter(chapter);document.documentElement.dataset.world=w.key;if(appliedWorldImage!==w.image){document.documentElement.style.setProperty('--world-image',`url("${w.image}")`);appliedWorldImage=w.image;}document.documentElement.style.setProperty('--accent',w.accent)}
function svgElement(name,attrs={}){const el=document.createElementNS('http://www.w3.org/2000/svg',name);for(const [k,v] of Object.entries(attrs))el.setAttribute(k,String(v));return el}
function setRoadToken(point,id){$('#road-token').setAttribute('transform',`translate(${point.x},${point.y-51})`);$('#road-svg').dataset.position=String(id)}
function roadControls(){if(document.activeElement!==$('#test-level'))$('#test-level').value=selectedRoadLevel;for(const b of $('#chapter-tabs').querySelectorAll('button'))b.disabled=mapMoving;$('#close-levels').disabled=mapMoving;$('#road-home').disabled=mapMoving;$('#road-play').disabled=mapMoving||selectedRoadLevel>unlocked;$('#road-play').textContent=mapMoving?'Переходим…':selectedRoadLevel>unlocked?'Пока закрыт':'Играть · '+selectedRoadLevel;$('#road-caption').textContent=mapMoving?'Желейка идёт к следующему уровню…':selectedRoadLevel>unlocked?'Пройди предыдущие уровни':(completed[selectedRoadLevel]?'Можно пройти ещё раз':'Уровень '+selectedRoadLevel+' · '+(level(selectedRoadLevel).puzzleTitle||level(selectedRoadLevel).title));}
function selectRoadLevel(id){if(mapMoving)return;selectedRoadLevel=id;if(worldMap)worldMap.selected=id;for(const b of $('#road-nodes').querySelectorAll('button')){b.classList.toggle('selected',Number(b.dataset.level)===id);b.setAttribute('aria-pressed',String(Number(b.dataset.level)===id))}roadControls()}
function centerRoad(id){if(worldMap){worldMap.focus(id,true);return}const p=roadPoint(id,mapChapter),scroll=$('#road-scroll');scroll.scrollTop=Math.max(0,p.y-scroll.clientHeight*.63)}
function worldHeader(chapter){mapChapter=Math.max(0,Math.min(9,chapter));const world=worldForChapter(mapChapter);$('#road-world').textContent=world.name;$('#road-chapter').textContent=chapterNames[mapChapter]+' · уровни '+(mapChapter*50+1)+'–'+(mapChapter*50+50);for(const [i,button] of [...$('#chapter-tabs').children].entries())button.classList.toggle('selected',i===mapChapter);}
function startWorldMap(){
 if(worldDisabled)return;
 try{if(!worldMap)worldMap=new globalThis.SdvigWorldMap($('#road-scroll'),{unlocked,completed,onSelect:id=>{selectedRoadLevel=id;roadControls();},onChapter:worldHeader,onError:message=>{console.warn(message);worldDisabled=true;$('#road-scroll').classList.remove('world-mode');worldMap?.dispose();worldMap=null;drawRoad();requestAnimationFrame(()=>centerRoad(selectedRoadLevel));}});
 else worldMap.setOptions({unlocked,completed});$('#road-scroll').classList.add('world-mode');worldMap.selected=selectedRoadLevel;worldMap.start();
 }catch(error){console.warn('3D map unavailable; sprite map fallback:',error.message);worldDisabled=true;$('#road-scroll').classList.remove('world-mode');worldMap?.dispose();worldMap=null;}
}
function drawRoadDecor(){
 let layer=$('#road-decor');if(!layer){layer=document.createElement('div');layer.id='road-decor';layer.setAttribute('aria-hidden','true');$('#road-inner').prepend(layer);}layer.replaceChildren();
 const names=['ocean','ringed','meteors','comet','lava','moon'];
 for(let i=1;i<50;i+=2){const id=mapChapter*50+i+1,p=roadPoint(id,mapChapter),dec=document.createElement('div');dec.className='road-decoration '+(p.x>180?'left':'right');dec.style.top=(p.y-55)+'px';const im=document.createElement('img');im.src='assets/space-'+names[(Math.floor(i/2)+mapChapter)%names.length]+'.webp';im.alt='';im.loading='lazy';dec.append(im);for(let n=0;n<3;n++){const mote=document.createElement('i');mote.className='road-firefly';mote.style.setProperty('--n',n);dec.append(mote);}layer.append(dec);}
 const flag=document.createElement('div');flag.className='chapter-flag';flag.style.top='9px';flag.textContent='ГЛАВА '+(mapChapter+1)+' · '+chapterNames[mapChapter];layer.append(flag);
}
function drawRoad(){const world=worldForChapter(mapChapter),dialog=$('#level-dialog');dialog.dataset.world=world.key;dialog.style.setProperty('--world-image',`url("${world.image}")`);dialog.style.setProperty('--accent',world.accent);$('#road-world').textContent=world.name;$('#road-chapter').textContent=chapterNames[mapChapter]+' · уровни '+(mapChapter*50+1)+'–'+(mapChapter*50+50);
 $('#chapter-tabs').replaceChildren();chapters.forEach(([title],i)=>{const b=document.createElement('button');b.textContent=(i+1)+' · '+title;b.className=i===mapChapter?'selected':'';b.onclick=()=>showMap(i);$('#chapter-tabs').append(b)});
 drawRoadDecor();const svg=$('#road-svg');svg.setAttribute('viewBox',`0 0 ${ROAD_WIDTH} ${ROAD_HEIGHT}`);svg.replaceChildren();$('#road-inner').style.height=ROAD_HEIGHT+'px';
 for(let i=0;i<49;i++){const id=mapChapter*50+i+1,d=roadSegment(roadPoint(id,mapChapter),roadPoint(id+1,mapChapter));svg.append(svgElement('path',{d,class:'road-track-shadow'}),svgElement('path',{d,class:'road-track '+(id<unlocked?'done':'')}),svgElement('path',{d,class:'road-dots'}))}
 const nodes=$('#road-nodes');nodes.replaceChildren();for(let i=0;i<50;i++){const id=mapChapter*50+i+1,p=roadPoint(id,mapChapter),stars=completed[id]||0,b=document.createElement('button');b.id='road-node-'+id;b.dataset.level=id;b.style.left=p.x/ROAD_WIDTH*100+'%';b.style.top=p.y+'px';b.className='road-node '+(id%25===0?'treasure ':'')+(stars?'complete':id===unlocked?'next':'')+(id===selectedRoadLevel?' selected':'');b.disabled=id>unlocked;b.setAttribute('aria-label','Уровень '+id+(id>unlocked?' закрыт':stars?' пройден, звёзд '+stars:' доступен'));b.setAttribute('aria-pressed',String(id===selectedRoadLevel));const number=document.createElement('b');number.textContent=id;b.append(number);if(stars){const small=document.createElement('span');small.className='road-stars';small.textContent='★'.repeat(stars);b.append(small)}else if(id>unlocked){const lock=document.createElement('span');lock.className='road-lock';const icon=document.createElement('img');icon.src='assets/lock-opal.webp';icon.alt='';icon.width=24;icon.height=28;lock.append(icon);b.append(lock)}const lc=level(id);if(lc.lesson||id%25===0){const label=document.createElement('span');label.className='road-milestone';label.textContent=id%25===0?'Испытание':({detour:'Объезд',portal:'Порталы',switch:'Развилка',pins:'Штифты',bombs:'Бомбы',beacons:'Маяки',runes:'Печати',compass:'Компас',singleStep:'Точный шаг',tide:'Прилив',pair:'Связанные ряды',lock:'Ключ',glass:'Стекло',line:'Линии',corner:'Уголки',tee:'Буква Т'}[lc.focus]||'Открытие');b.append(label);}b.onclick=()=>selectRoadLevel(id);nodes.append(b)}
 const token=svgElement('g',{id:'road-token','aria-label':'Желейка-путешественник'});token.append(svgElement('ellipse',{cx:0,cy:29,rx:18,ry:4,fill:'#041326',opacity:.4}),svgElement('image',{href:'assets/jelly-aqua-opal.webp',x:-32,y:-32,width:64,height:64,id:'road-avatar-image'}));svg.append(token);
 const markerChapter=chapterForLevel(roadPosition);token.style.display=markerChapter===mapChapter?'':'none';if(markerChapter===mapChapter)setRoadToken(roadPoint(roadPosition,mapChapter),roadPosition);roadControls();startWorldMap();
}
function animateRoad(move){if(worldMap){worldMap.focus(move.to);roadPosition=move.to;pendingRoadMove=null;saveCampaign();return}if(!validRoadMove(move,unlocked)){pendingRoadMove=null;return}mapMoving=true;roadControls();const token=$('#road-token');token.style.display='';token.dataset.moving='true';const to=roadPoint(move.to,mapChapter),from=chapterForLevel(move.from)===mapChapter?roadPoint(move.from,mapChapter):{x:180,y:ROAD_HEIGHT-8};const path=svgElement('path',{d:roadSegment(from,to)});$('#road-svg').append(path);path.style.visibility='hidden';const length=path.getTotalLength(),start=performance.now(),ms=reduced?1:1100;setRoadToken(from,move.from);centerRoad(move.to);
 function frame(now){if(!$('#level-dialog').open)return;const t=Math.min(1,(now-start)/ms),p=path.getPointAtLength(length*(t*t*(3-2*t)));setRoadToken(p,t<1?move.from:move.to);if(t<1){roadAnimation=requestAnimationFrame(frame);return}path.remove();mapMoving=false;token.dataset.moving='false';roadPosition=Math.max(roadPosition,move.to);pendingRoadMove=null;$('#road-svg').dataset.movedFrom=String(move.from);$('#road-svg').dataset.movedTo=String(move.to);roadControls();saveCampaign()}
 roadAnimation=requestAnimationFrame(frame);
}
function showMap(ch=mapChapter,move=null){if(mapMoving)return;mapChapter=Math.max(0,Math.min(9,ch));selectedRoadLevel=move?move.to:Math.max(mapChapter*50+1,Math.min(mapChapter*50+50,config.id));drawRoad();if(!$('#level-dialog').open)$('#level-dialog').showModal();requestAnimationFrame(()=>{if(!$('#level-dialog').open)return;if(move)animateRoad(move);else centerRoad(worldMap?selectedRoadLevel:chapterForLevel(roadPosition)===mapChapter?roadPosition:selectedRoadLevel)})}
function openJourney(){const move=validRoadMove(pendingRoadMove,unlocked)?pendingRoadMove:null;showMap(move?chapterForLevel(move.to):config.chapter,move);if(!move)selectRoadLevel(Math.min(config.id+1,unlocked))}
function closeJourney(){if(mapMoving)return;worldMap?.stop();cancelAnimationFrame(roadAnimation);$('#level-dialog').close();last=performance.now();if(finished&&!$('#result-dialog').open)$('#result-dialog').showModal()}
$('#levels').onclick=()=>{if(busy||paused)return;showMap(config.chapter)};$('#close-levels').onclick=closeJourney;$('#result-map').onclick=()=>{$('#result-dialog').close();if(finished)openJourney();else showMap(config.chapter)};
$('#road-play').onclick=()=>{if(mapMoving||selectedRoadLevel>unlocked)return;$('#level-dialog').close();last=performance.now();if(selectedRoadLevel!==config.id||finished)startLevel(selectedRoadLevel)};
$('#road-home').onclick=()=>{if(mapMoving)return;showMap(chapterForLevel(unlocked));selectRoadLevel(unlocked);centerRoad(unlocked)};
$('#level-dialog').addEventListener('cancel',e=>{e.preventDefault();closeJourney()});
function load(url){return new Promise((resolve,reject)=>{const image=new Image();image.onload=()=>resolve(image);image.onerror=()=>reject(Error(url));image.src=url})}
function vibrant(image){const buffer=document.createElement('canvas');buffer.width=image.width;buffer.height=image.height;const g=buffer.getContext('2d');g.filter='saturate(1.3) contrast(1.1) brightness(1.04)';g.drawImage(image,0,0);return buffer}
async function init(){
 document.documentElement.dataset.ready='false';
 try{const [loaded,sad,panes,shards,hardware,mechanics]=await Promise.all([
  Promise.all(names.map(name=>load('assets/jelly-'+name+'-opal.webp'))),
  Promise.all(names.map(name=>load('assets/jelly-'+name+'-sad.webp'))),
  Promise.all(['clear','cracked'].map(name=>load('assets/tile-glass-'+name+'.webp'))),
  Promise.all(Array.from({length:6},(_,i)=>load('assets/glass-shard-'+i+'.webp'))),
  Promise.all(['chain-gold','lock-opal','key-opal'].map(name=>load('assets/'+name+'.webp'))),
  Promise.all(['bomb-opal','pin-opal'].map(name=>load('assets/'+name+'.webp')))
 ]);sprites.push(...loaded);sadSprites.push(...sad);glassSprites.push(...panes);glassShards.push(...shards);lockArt.push(...hardware);mechanicArt.push(...mechanics);
  [extraArt.rune,extraArt.portal,extraArt.switch]=await Promise.all(['rune-opal','portal-opal','switch-opal'].map(name=>load('assets/'+name+'.svg')));ready=true;document.documentElement.dataset.ready='true';$('#loading').hidden=true;let saved=readSave();startLevel(config.id,saved?.board);if(validRoadMove(pendingRoadMove,unlocked)){$('#result-dialog').close();openJourney();}
 }catch(e){$('#loading').textContent='Не загрузилась графика. Нажми, чтобы повторить.';$('#loading').onclick=()=>location.reload();console.error('Image load failed',e.message)}
}
if(TEST_MODE)globalThis.sdvigTest={state:()=>({config,capture:capture(),grid:grid.map(row=>row.map(t=>({color:t.color,bomb:!!t.bomb}))),busy,finished}),open:id=>{if(busy)return false;for(const d of document.querySelectorAll("dialog[open]"))d.close();startLevel(id);return true},hint:()=>config.modern?modernHint():authoredHint(),move:m=>{if(busy||paused||finished)return false;if(m.bomb!=null){activateModernBomb(m.bomb);return true}drag={axis:m.axis,r:m.axis==='x'?m.index:2,c:m.axis==='y'?m.index:2,offset:0,velocity:0};beginSettle(drag,m.n,true);return true},advance:ms=>{for(let i=0;i<ms;i+=100)tick(Math.min(100,ms-i))}};
soundUi();resize();requestAnimationFrame(render);init();

})();
