/* A streamed, real WebGL world. No external assets or network are needed. */
(function(){'use strict';
const T=globalThis.THREE;
const palettes=[{sky:0x69d9ec,land:0x87df91,edge:0x6f9b65,road:0xffd9a0,leaf:0x35ac77,crystal:0x80f5ec},{sky:0xa9b9f4,land:0x9ce5ee,edge:0x759fcb,road:0xe9dcff,leaf:0x518dbd,crystal:0x8cffff},{sky:0xffd0a4,land:0xc3e99c,edge:0x97a4b1,road:0xffecc3,leaf:0x5cae85,crystal:0xe9a5ff}];
const center=t=>Math.sin(t*.027)*7+Math.sin(t*.009)*3;
const height=t=>Math.sin(t*.012)*.6;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
class WorldMap{
 constructor(host,options){
 this.host=host;this.options=options;this.position=0;this.target=0;this.velocity=0;this.selected=1;this.chunks=new Map();this.buttons=new Map();this.materials=new Map();this.running=false;this.last=0;this.drag=null;this.suppressUntil=0;this.reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
 this.scene=new T.Scene();this.scene.fog=new T.Fog(palettes[0].sky,85,185);this.camera=new T.PerspectiveCamera(48,1,.2,230);
 this.renderer=new T.WebGLRenderer({antialias:true,alpha:true,powerPreference:'low-power'});this.renderer.setPixelRatio(Math.min(devicePixelRatio||1,1.6));this.renderer.setClearColor(0,0);this.renderer.outputColorSpace=T.SRGBColorSpace;this.renderer.setAnimationLoop(null);
 this.canvas=this.renderer.domElement;this.canvas.id='world-canvas';this.canvas.setAttribute('aria-label','Объёмная карта: потяните вверх или вниз, используйте колесо или стрелки.');this.canvas.tabIndex=0;
 this.labels=document.createElement('div');this.labels.id='world-labels';this.instructions=document.createElement('div');this.instructions.className='world-instructions';this.instructions.textContent='Потяни мир · колесо / ↑ ↓';
 host.append(this.canvas,this.labels,this.instructions);
 this.scene.add(new T.HemisphereLight(0xffffff,0x7b96ac,2.2));const sun=new T.DirectionalLight(0xfff3d4,3.3);sun.position.set(-25,45,30);this.scene.add(sun);const fill=new T.DirectionalLight(0xc2f5ff,1);fill.position.set(20,10,-20);this.scene.add(fill);
 this.geometries={ball:new T.SphereGeometry(1,12,8),cone:new T.ConeGeometry(1,1,7),cylinder:new T.CylinderGeometry(1,1,1,20),rock:new T.IcosahedronGeometry(1,0),crystal:new T.OctahedronGeometry(1,0),ring:new T.TorusGeometry(2.3,.16,6,32),cube:new T.BoxGeometry(1,1,1)};
 this.clouds=[];for(let i=0;i<13;i++){const cloud=new T.Group();for(let k=0;k<3;k++)this.add(cloud,'ball',0xffffff,k*2-2,k===1?.6:0,0,2.2,1.1+k*.2,1.4);this.scene.add(cloud);this.clouds.push(cloud);}
 this.ring=new T.Mesh(this.geometries.ring,this.mat(0xffe6a0));this.ring.rotation.x=-Math.PI/2;this.scene.add(this.ring);
 const portrait=document.querySelector('.result-jelly')?.src;if(portrait){this.heroTexture=new T.TextureLoader().load(portrait);this.heroTexture.colorSpace=T.SRGBColorSpace;this.hero=new T.Sprite(new T.SpriteMaterial({map:this.heroTexture,transparent:true,depthTest:true}));this.hero.scale.set(2.8,2.8,1);this.scene.add(this.hero);}
 this.bind();this.resizeObserver=new ResizeObserver(()=>this.resize());this.resizeObserver.observe(host);this.resize();
 this.contextLost=e=>{e.preventDefault();this.options.onError?.('Контекст 3D потерян. Закройте и снова откройте карту.');this.stop();};this.canvas.addEventListener('webglcontextlost',this.contextLost);
 }
 mat(color){if(!this.materials.has(color))this.materials.set(color,new T.MeshStandardMaterial({color,roughness:.7,metalness:.03,flatShading:true}));return this.materials.get(color);}
 add(group,type,color,x,y,z,sx=1,sy=sx,sz=sx){const m=new T.Mesh(this.geometries[type],this.mat(color));m.position.set(x,y,z);m.scale.set(sx,sy,sz);group.add(m);return m;}
 tree(g,x,z,size,p,snow){this.add(g,'cylinder',0x97684b,x,2*size,z,.38*size,4*size,.38*size);for(let k=0;k<3;k++){const r=(2.8-k*.55)*size,y=(3.2+k*1.5)*size;this.add(g,'cone',p.leaf,x,y,z,r,3*size,r);if(snow)this.add(g,'cone',0xf6ffff,x,y+.7*size,z,r*.74,1.8*size,r*.74);}}
 mushroom(g,x,z,s){this.add(g,'cylinder',0xffefcf,x,s*1.3,z,.65*s,2.6*s,.65*s);this.add(g,'ball',0xff9f9d,x,s*2.65,z,2.2*s,.85*s,2.2*s);for(let k=0;k<5;k++){const a=k*2.3;this.add(g,'ball',0xfff6d8,x+Math.cos(a)*s*1.35,s*3.15,z+Math.sin(a)*s*1.35,.28*s,.13*s,.28*s);}}
 crystals(g,x,z,s,p){for(let k=0;k<4;k++){const a=k*2.4;const m=this.add(g,'crystal',p.crystal,x+Math.cos(a)*s,s*(1.2+k*.35),z+Math.sin(a)*s,.7*s,(2+k*.5)*s,.7*s);m.rotation.z=(k-1.5)*.14;}}
 house(g,x,z,p){this.add(g,'cylinder',0xffe7b5,x,1.7,z,2.4,3.4,2.4);this.add(g,'ball',0xfaa5af,x,3.8,z,3.2,1.2,3.2);this.add(g,'cube',0x9c6d53,x,1.1,z+2.4,.9,2.2,.12);this.add(g,'ball',0xfff5b0,x+1.4,2.1,z+2,.4,.4,.15);this.add(g,'cylinder',0xe1c2c4,x+1.4,4.6,z-.5,.35,2,.35);}
 gate(g,p){for(const x of [-3,3]){this.add(g,'cylinder',0xffedb5,x,3,0,.65,6,.65);this.add(g,'ball',p.crystal,x,6.2,0,1,.7,1);}this.add(g,'cube',0xffd887,0,5.6,0,6.5,.8,1.2);this.add(g,'ball',0xdfacff,0,3,0,2.2,2.5,.3);}
 ribbon(i,p){const positions=[],colors=[],segments=8;const colTop=new T.Color(p.land),colSide=new T.Color(p.edge);const start=(i-1)*12-6;
 const quad=(a,b,c,d,color)=>{for(const v of [a,b,c,a,c,d]){positions.push(...v);colors.push(color.r,color.g,color.b);}};
 for(let k=0;k<segments;k++){const a=start+k*12/segments,b=start+(k+1)*12/segments,xa=center(a),xb=center(b),ya=height(a),yb=height(b),w=6.1;
 quad([xa-w,ya,-a],[xa+w,ya,-a],[xb+w,yb,-b],[xb-w,yb,-b],colTop);
 quad([xa-w,ya-2.2,-a],[xa-w,ya,-a],[xb-w,yb,-b],[xb-w,yb-2.2,-b],colSide);
 quad([xa+w,ya,-a],[xa+w,ya-2.2,-a],[xb+w,yb-2.2,-b],[xb+w,yb,-b],colSide);
 }
 const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(positions,3));geo.setAttribute('color',new T.Float32BufferAttribute(colors,3));geo.computeVertexNormals();const material=new T.MeshStandardMaterial({vertexColors:true,roughness:.9,side:T.DoubleSide});return new T.Mesh(geo,material);
 }
 bake(group){group.updateMatrixWorld(true);const bins=new Map(),terrain=group.userData.terrain;group.traverse(obj=>{if(!obj.isMesh||obj===terrain)return;const key=obj.material.uuid;if(!bins.has(key))bins.set(key,{material:obj.material,positions:[],normals:[]});const bin=bins.get(key),geo=obj.geometry.index?obj.geometry.toNonIndexed():obj.geometry.clone();geo.applyMatrix4(obj.matrixWorld);bin.positions.push(geo.attributes.position.array.slice());bin.normals.push(geo.attributes.normal.array.slice());geo.dispose();});
 for(const child of [...group.children])if(child!==terrain)group.remove(child);group.userData.baked=[];
 for(const bin of bins.values()){const concatenate=arrays=>{const result=new Float32Array(arrays.reduce((a,b)=>a+b.length,0));let offset=0;for(const array of arrays){result.set(array,offset);offset+=array.length;}return result;};const geo=new T.BufferGeometry();geo.setAttribute('position',new T.BufferAttribute(concatenate(bin.positions),3));geo.setAttribute('normal',new T.BufferAttribute(concatenate(bin.normals),3));group.add(new T.Mesh(geo,bin.material));group.userData.baked.push(geo);}
 }
 chunk(i){const index=i-1,t=index*12,chapter=Math.floor(index/50),p=palettes[chapter%3],g=new T.Group();g.userData.id=i;
 const terrain=this.ribbon(i,p);g.add(terrain);g.userData.terrain=terrain;
 // A cream trail lies on top of the continuous floating land strip.
 for(let k=0;k<4;k++){const d=t-4.5+k*3,x=center(d),y=height(d);const tile=this.add(g,'cylinder',p.road,x,y+.06,-d,1.75,.12,1.5);tile.rotation.y=Math.sin(d*.03)*.15;}
 const x=center(t),y=height(t);this.add(g,'cone',p.edge,x,y-2.5,-t,5.1,4.7,5.1).rotation.z=Math.PI;
 const base=this.add(g,'cylinder',0xfff5d8,x,y+.28,-t,2.1,.5,2.1);const done=!!this.options.completed?.[i],locked=i>this.options.unlocked;
 this.add(g,'cylinder',done?0xffc457:locked?0xaaa9c8:0x37c4de,x,y+1.35,-t,1.65,1.65,1.65);this.add(g,'cylinder',done?0xffdf8c:locked?0xc4c9e1:0x74e8f6,x,y+2.2,-t,1.65,.12,1.65);
 const left=-1,right=1,offset=(i%2?left:right)*4.9,local=new T.Group();local.position.set(x,y,-t);g.add(local);
 if(i%10===0)this.gate(local,p);
 else if(i%7===0)this.house(local,offset,1,p);
 else if(chapter%3===1&&i%2===0||i%3===0)this.crystals(local,offset,0,.9+(i%2)*.3,p);
 else this.tree(local,offset,1,.8+(i%3)*.18,p,chapter%3===1);
 if(i%4===1)this.mushroom(local,-offset,2,.55);
 else this.add(local,'ball',p.leaf,-offset,.55,1,1.1,.7,1.2);
 for(let k=0;k<3;k++){const sx=x+(k%2?-1:1)*(3.4+k*.45),zz=-t+2+k*1.3;this.add(g,'ball',[0xffe9aa,0xffb4d7,0xf6f7ff][k],sx,height(t)+.35,zz,.2,.25,.2);}
 this.bake(g);this.scene.add(g);this.chunks.set(i,g);
 const button=document.createElement('button');button.className='world-level'+(locked?' locked':'')+(done?' done':'');button.dataset.level=i;button.setAttribute('aria-label','Уровень '+i+(locked?' закрыт':done?' пройден':''));button.innerHTML='<b>'+i+'</b>'+(done?'<small>'+'★'.repeat(this.options.completed[i])+'</small>':'');button.onclick=()=>{if(performance.now()<this.suppressUntil)return;this.select(i);};button.onkeydown=e=>{if(e.key===' '||e.key==='Enter'){e.stopPropagation();}};this.labels.append(button);this.buttons.set(i,button);
 }
 remove(i){const g=this.chunks.get(i);this.scene.remove(g);for(const geo of g.userData.baked||[])geo.dispose();g.userData.terrain.geometry.dispose();g.userData.terrain.material.dispose();this.chunks.delete(i);this.buttons.get(i)?.remove();this.buttons.delete(i);}
 updateChunks(){const near=Math.floor(this.position/12)+1,min=Math.max(1,near-4),max=Math.min(500,near+17);for(const i of this.chunks.keys())if(i<min||i>max)this.remove(i);for(let i=min;i<=max;i++)if(!this.chunks.has(i))this.chunk(i);}
 setOptions(options){this.options={...this.options,...options};for(const i of [...this.chunks.keys()])this.remove(i);}
 select(i,immediate=false){this.selected=i;this.options.onSelect(i);this.focus(i,immediate);}
 focus(i,immediate=false){i=clamp(i,1,500);this.target=(i-1)*12;this.velocity=0;if(immediate||this.reduced)this.position=this.target;this.selected=i;this.start();}
 moveBy(d){this.target=clamp(this.target+d,0,499*12);this.velocity=0;this.start();}
 resize(){const w=this.host.clientWidth,h=this.host.clientHeight;if(!w||!h||w===this.width&&h===this.height)return;this.width=w;this.height=h;this.renderer.setSize(w,h,false);this.camera.aspect=w/h;this.camera.fov=w<h?56:38;this.camera.updateProjectionMatrix();}
 bind(){const host=this.host;
 host.addEventListener('pointerdown',e=>{if(e.button>0)return;this.drag={id:e.pointerId,start:e.clientY,last:e.clientY,time:performance.now(),moved:0};if(!e.target.closest('.world-level'))host.setPointerCapture(e.pointerId);this.velocity=0;this.canvas.focus({preventScroll:true});});
 host.addEventListener('pointermove',e=>{if(!this.drag||e.pointerId!==this.drag.id)return;const d=this.drag,now=performance.now(),dy=e.clientY-d.last,dt=Math.max(8,now-d.time);d.moved=Math.max(d.moved,Math.abs(e.clientY-d.start));const units=dy*.075;this.target=clamp(this.target+units,0,499*12);this.velocity=clamp(units/dt*1000,-90,90);d.last=e.clientY;d.time=now;if(d.moved>7){this.suppressUntil=now+300;if(!host.hasPointerCapture(e.pointerId))host.setPointerCapture(e.pointerId);}});
 const end=(e,cancel)=>{if(!this.drag)return;if(!cancel&&this.drag.moved>7&&!this.reduced)this.target=clamp(this.target+this.velocity*.18,0,499*12);this.velocity=0;this.drag=null;};host.addEventListener('pointerup',e=>end(e,false));host.addEventListener('pointercancel',e=>end(e,true));host.addEventListener('lostpointercapture',e=>end(e,true));
 host.addEventListener('wheel',e=>{e.preventDefault();const d=e.deltaY*(e.deltaMode===1?16:1);this.moveBy(clamp(d*.055,-24,24));},{passive:false});
 this.canvas.addEventListener('keydown',e=>{const d={ArrowUp:12,ArrowDown:-12,PageUp:60,PageDown:-60};if(e.key in d){e.preventDefault();this.moveBy(d[e.key]);}else if(e.key==='Home'){e.preventDefault();this.select(1,true);}else if(e.key==='End'){e.preventDefault();this.select(this.options.unlocked,true);}});
 }
 start(){if(this.running)return;this.running=true;this.last=performance.now();this.raf=requestAnimationFrame(t=>this.frame(t));}
 stop(){this.running=false;cancelAnimationFrame(this.raf);this.drag=null;}
 frame(now){if(!this.running)return;if(!this.host.closest('dialog')?.open){this.stop();return;}const dt=Math.min(.05,(now-this.last)/1000);this.last=now;this.resize();this.position+=this.reduced?this.target-this.position:clamp((this.target-this.position)*(1-Math.exp(-dt*7)),-18,18);if(Math.abs(this.position-this.target)<.002)this.position=this.target;this.updateChunks();
 const t=this.position,cx=center(t),chapter=Math.floor((Math.floor(t/12))/50),palette=palettes[chapter%3];this.scene.fog.color.lerp(new T.Color(palette.sky),1-Math.exp(-dt*2.5));this.host.style.setProperty('--sky','#'+this.scene.fog.color.getHexString());
 const sway=this.reduced?0:Math.sin(now*.00065)*.12;this.camera.position.set(cx*.72+sway,17+height(t),-t+22);this.camera.lookAt(center(t+20)*.7,height(t+20)+.7,-t-20);this.camera.updateMatrixWorld();
 for(let i=0;i<this.clouds.length;i++){const c=this.clouds[i],d=t+((i*23+18)%260)-35;c.position.set(center(d)+(i%2?-1:1)*(12+i%3*5),(i%3===0?13:3)+(i%4)*1.8,-d);c.rotation.y=i*.6;}
 const st=(this.selected-1)*12;this.ring.position.set(center(st),height(st)+2.35+(this.reduced?0:Math.sin(now*.003)*.08),-st);this.ring.scale.setScalar(1+(this.reduced?0:Math.sin(now*.002)*.05));
 if(this.hero){this.hero.position.set(center(st),height(st)+4.25+(this.reduced?0:Math.sin(now*.002)*.13),-st);}
 this.renderer.render(this.scene,this.camera);const v=new T.Vector3();
 for(const [i,button] of this.buttons){const d=(i-1)*12-t;v.set(center((i-1)*12),height((i-1)*12)+1.5,-(i-1)*12);v.project(this.camera);const visible=v.z>-1&&v.z<1&&Math.abs(v.x)<1.2&&Math.abs(v.y)<1.15&&d>-10&&d<104;button.hidden=!visible;if(!visible)continue;const scale=clamp(42/(d+39),.42,1.2);button.style.left=(v.x*.5+.5)*this.width+'px';button.style.top=(-v.y*.5+.5)*this.height+'px';button.style.transform=`translate(-50%,-50%) scale(${scale})`;button.classList.toggle('selected',i===this.selected);button.setAttribute('aria-pressed',String(i===this.selected));}
 const current=clamp(Math.floor(t/12)+1,1,500);this.canvas.dataset.position=this.position.toFixed(3);this.canvas.dataset.nearest=String(current);this.canvas.dataset.visibleChunks=String(this.chunks.size);this.canvas.dataset.webgl='true';this.canvas.dataset.triangles=String(this.renderer.info.render.triangles);if(this.chapter!==chapter){this.chapter=chapter;this.options.onChapter?.(chapter);}
 this.raf=requestAnimationFrame(n=>this.frame(n));
 }
 dispose(){this.stop();this.resizeObserver.disconnect();for(const i of [...this.chunks.keys()])this.remove(i);for(const g of Object.values(this.geometries))g.dispose();for(const m of this.materials.values())m.dispose();this.heroTexture?.dispose();this.hero?.material.dispose();this.renderer.dispose();this.canvas.remove();this.labels.remove();this.instructions.remove();}
}
globalThis.SdvigWorldMap=WorldMap;
})();
