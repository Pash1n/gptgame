const {chromium}=require('playwright'),fs=require('node:fs');
(async()=>{
const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox']});const page=await browser.newPage({viewport:{width:1440,height:1000}}),errors=[],results=[],started=Date.now();
page.on('pageerror',e=>errors.push(e.message));page.on('response',r=>{if(r.status()>=400)errors.push('HTTP '+r.status()+' '+r.url())});
await page.goto((process.env.SDVIG_URL||'http://127.0.0.1:8015/')+'?test=1');await page.waitForFunction(()=>document.documentElement.dataset.ready==='true');
for(let first=1;first<=500;first+=25){
 const group=await page.evaluate(({first,last})=>{
 const rows=[];
 const parity=(expected,actual,id,step)=>{
 const cap=actual.capture,m=cap.modern;
 const wanted=JSON.stringify([expected.grid.map(r=>r.map(t=>[t.color,!!t.bomb])),expected.pins,expected.progress,expected.terrain,expected.rngState|0,expected.locked,expected.beacon,expected.runes,expected.turn,expected.tides||0,expected.routeSide||-1,expected.detourUses||0,expected.portalUses||0,expected.switchCount||0]);
 const got=JSON.stringify([actual.grid.map(r=>r.map(t=>[t.color,!!t.bomb])),m.pins,m.progress,cap.terrain,cap.rngState|0,cap.locked,m.extra.beacon,m.extra.runes,cap.turns,m.extra.tides||0,m.extra.routeSide||-1,m.extra.detourUses||0,m.extra.portalUses||0,m.extra.switchCount||0]);
 if(wanted!==got)throw Error('Parity at level '+id+' step '+step+'\n'+wanted+'\n'+got);
 };
 for(let id=first;id<=last;id++){
 sdvigTest.advance(3000);if(!sdvigTest.open(id))throw Error('Cannot open '+id);sdvigTest.advance(3000);
 let actual=sdvigTest.state(),config=actual.config,expected=config.modern?SdvigCampaign.initial(config):null;
 if(expected)parity(expected,actual,id,0);
 for(let step=0;step<config.solution.length;step++){
 const move=config.solution[step];if(!sdvigTest.move(move))throw Error('Move refused '+id+' step '+step);
 if(expected)expected=SdvigCampaign.simulate(expected,move,config);
 sdvigTest.advance(20000);actual=sdvigTest.state();
 if(actual.busy)throw Error('Animation stuck '+id);
 if(expected)parity(expected,actual,id,step+1);
 }
 if(!actual.finished||document.querySelector('#result-title').textContent!=='Получилось!')throw Error('Not won '+id);
 rows.push({id,passed:true,moves:actual.capture.turns,parityChecked:!!expected});
 }
 return rows;
 },{first,last:Math.min(500,first+24)});
 results.push(...group);console.log('Chromium',results.length,'/ 500');
}
const report={timestamp:new Date().toISOString(),browser:browser.version(),viewport:{width:1440,height:1000},method:'Real animation engine via test-mode API; tick advanced deterministically. Shared core compared after every modern move, including all board cells, bombs, objectives, locks, runes, beacons, tides and RNG. Not 500 manual drag-and-drop playthroughs.',passed:results.length,failed:0,moves:results.reduce((a,r)=>a+r.moves,0),errors,newMechanicsCompared:['routeSide','detourUses','portalUses','switchCount'],durationMs:Date.now()-started,levels:results};fs.writeFileSync('reports/levels-browser.json',JSON.stringify(report,null,2));await browser.close();console.log('Passed:',results.length,'Errors:',errors.length);if(errors.length)process.exitCode=1;
})().catch(e=>{console.error(e);process.exit(1)});
