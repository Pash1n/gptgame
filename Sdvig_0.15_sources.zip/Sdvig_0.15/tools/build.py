"""Package runtime and sources without modifying the project or original upload."""
import argparse, hashlib, json, zipfile
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
parser = argparse.ArgumentParser()
parser.add_argument('--out', default='/workspace/artifacts')
parser.add_argument('--original', default='/workspace/attachments/a77d3939-b2f7-44f1-bbc6-44f5cf4aaead/Sdvig_0.12_PIKABU_TEST.zip')
args = parser.parse_args()
out = Path(args.out)
out.mkdir(parents=True, exist_ok=True)
runtime = ['index.html','test.html','style.css','glass-ui.css','journey.css','trail.css','world-map.css','world-map.js','vendor/three.js','vendor/THREE-LICENSE.txt','campaign-core.js','campaign-levels.js','game.js','README_RU.md']
files = [ROOT / name for name in runtime] + sorted((ROOT / 'assets').rglob('*'))
files = [f for f in files if f.is_file()]
manifest = {'version':'0.15.0', 'runtime_bytes':sum(f.stat().st_size for f in files), 'files':{str(f.relative_to(ROOT)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files}}
assert manifest['runtime_bytes'] < 100_000_000
with zipfile.ZipFile(out/'Sdvig_0.15_build.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for f in files: z.write(f,str(f.relative_to(ROOT)))
    z.writestr('MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2))
    z.write(ROOT/'reports/REPORT_RU.md','REPORT_RU.md')
with zipfile.ZipFile(out/'Sdvig_0.15_sources.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for f in sorted(ROOT.rglob('*')):
        if f.is_file() and not any(p in ('node_modules','.git','__pycache__') for p in f.relative_to(ROOT).parts):
            z.write(f,'Sdvig_0.15/'+str(f.relative_to(ROOT)))
    original=Path(args.original)
    if original.is_file():
        z.write(original,'original/Sdvig_0.12_PIKABU_TEST.zip')
        manifest['original_sha256']=hashlib.sha256(original.read_bytes()).hexdigest()
    z.writestr('MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2))
checksums = []
for f in [out/'Sdvig_0.15_build.zip',out/'Sdvig_0.15_sources.zip']:
    assert f.stat().st_size<100_000_000
    checksums.append(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.name)
    print(f.name, f.stat().st_size, 'bytes')
(out/'SHA256SUMS.txt').write_text('\n'.join(checksums)+'\n')
(out/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
(out/'REPORT_RU.md').write_text((ROOT/'reports/REPORT_RU.md').read_text())
