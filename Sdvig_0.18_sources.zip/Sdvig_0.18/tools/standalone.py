"""Build a single-file test edition with all 500 levels unlocked."""
import base64,json,re,mimetypes
from pathlib import Path
root=Path(__file__).resolve().parent.parent
out=Path('/workspace/artifacts/Sdvig_0.18_TEST_ALL_500.html')
art={}
for p in sorted((root/'assets').iterdir()):
 if p.is_file():art['assets/'+p.name]='data:'+mimetypes.guess_type(p.name)[0]+';base64,'+base64.b64encode(p.read_bytes()).decode()
html=(root/'index.html').read_text()
def css(match):
 name=match.group(1).split('?')[0];s=(root/name).read_text()
 return '<style>'+re.sub(r'url\(([\'"]?)(assets/[^\)\'\"]+)\1\)',lambda m:'var(--space-background)' if m.group(2)=='assets/space-galaxy.webp' else 'url("'+art[m.group(2)]+'")',s)+'</style>'
html=re.sub(r'<link rel="stylesheet" href="([^"]+)">',css,html)
html=re.sub(r'src="(assets/[^"]+)"',lambda m:'src="'+art[m.group(1)]+'"',html)
html=html.replace('</head>','<style>:root{--space-background:url("'+art['assets/space-galaxy.webp']+'")}</style></head>')
helper='const SDVIG_EMBEDDED_ART='+json.dumps(art,separators=(',',':'))+';function SDVIG_ASSET(path){return SDVIG_EMBEDDED_ART[path]||path;}\n'
def script(match):
 name=match.group(1).split('?')[0];s=(root/name).read_text()
 if name=='game.js':
  s=s.replace("const TEST_MODE=new URLSearchParams(location.search).get('test')==='1';",'const TEST_MODE=true;')
  s=s.replace("const testing=new URLSearchParams(location.search).get('test')==='1';",'const testing=true;')
  s=s.replace('sdvig-v14-sandbox','sdvig-v14-html-sandbox').replace('sdvig-v13-sandbox','sdvig-v13-html-sandbox')
  s=re.sub(r'(\b(?:img|pane|im|jewel|icon)\.src=)([^;]+);',lambda m:m.group(1)+'SDVIG_ASSET('+m.group(2)+');',s)
  s=s.replace("$('#pause img').src=value?'assets/cosmic-play.webp':'assets/cosmic-pause.webp';", "$('#pause img').src=SDVIG_ASSET(value?'assets/cosmic-play.webp':'assets/cosmic-pause.webp');")
  s=s.replace("$('#sound-image').src='assets/cosmic-sound-'+(sound?'on':'off')+'.webp'", "$('#sound-image').src=SDVIG_ASSET('assets/cosmic-sound-'+(sound?'on':'off')+'.webp')")
  s=s.replace("const SPACE_BACKGROUND='assets/space-galaxy.webp'","const SPACE_BACKGROUND=SDVIG_ASSET('assets/space-galaxy.webp')")
  s=s.replace('let config=level(1)', 'let config=level(131)')
  s=s.replace('image.src=url','image.src=SDVIG_ASSET(url)')
  s=s.replace("href:'assets/jelly-aqua-opal.webp'","href:SDVIG_ASSET('assets/jelly-aqua-opal.webp')")
  s=s.replace("image:'assets/space-galaxy.webp'","image:SDVIG_ASSET('assets/space-galaxy.webp')")
  for name in ['forest','lagoon','islands']:
   s=s.replace("image:'assets/world-"+name+".webp'", "image:SDVIG_ASSET('assets/world-"+name+".webp')")
 return '<script>'+s.replace('</script','<\\/script')+'</script>'
html=re.sub(r'<script defer src="([^"]+)"></script>',script,html)
html=html.replace('<body>','<body><script>'+helper+'</script>')
html=html.replace('<title>Сдвиг · Сквозь звёзды</title>','<title>Сдвиг 0.18 · Сквозь звёзды · Все 500 уровней</title>')
html=html.replace('</body>',"<script>if(!location.search){let tries=0;function openWorld(){if(++tries>1200)return;if(document.documentElement.dataset.ready==='true'&&document.documentElement.dataset.busy==='false'){if(!document.querySelector('dialog[open]'))document.getElementById('levels').click();}else requestAnimationFrame(openWorld);}requestAnimationFrame(openWorld);}</script></body>")
out.write_text(html)
print(out, out.stat().st_size,'bytes')
