# Cosmic artwork — 0.16

Two original images were generated specifically for the cosmic revision:

- `space-atlas.png` — transparent 1536×1024 atlas, 3 columns × 2 rows. Ocean planet, ringed gas giant, lava world; crystal meteorites, comet, rose/teal cratered moon. Extracted as six 512×512 WebP sprites under `assets/space-*.webp`.
- `milky-way.png` — deep navy Milky Way illustration with cyan/violet/magenta nebulae and star clouds. Runtime version: `assets/space-galaxy.webp`.

Art direction: original premium space fantasy, detailed painterly 3D volumes, luminous atmospheres, tactile minerals, cyan/violet/peach palette, readable isolated silhouettes. No text or numbers painted into assets. Sprites are used as perspective billboards in the WebGL world and in the fallback map. The galactic image is the distant background; 1260 actual 3D star particles provide additional depth.

Earlier map artwork retained in this source folder is historical and is not displayed by the cosmic revision. The unchanged 0.15 project remains separately available.
