const fs=require('node:fs'),C=require('../campaign-core.js'),{solve}=require('./generate.cjs');require('../campaign-levels.js');
const changes=[],levels=SDVIG_LEVELS,started=Date.now();
for(const c of levels){
 if(c.pins.length){c.detour=true;c.rulesChanged=true;c.revision=19;}
 if([52,53,54].includes(c.id)){c.pins=c.id===52?[14,8]:c.id===53?[14,15]:[14,16];c.detour=true;c.rulesChanged=true;c.revision=19;c.lesson=true;c.focus='detour';c.targets=[{color:0,count:4}];c.puzzleTitle={52:'Открытие · Объезд снизу',53:'Открытие · Две льдинки',54:'Открытие · Две стороны'}[c.id];}
 let s=C.initial(c),okay=true;try{for(const m of c.solution)s=C.simulate(s,m,c);okay=C.won(s,c);}catch{okay=false;}
 if(okay&&![52,53,54].includes(c.id))continue;
 const prefix=[52,53,54].includes(c.id)?[{axis:'x',index:2,n:1}]:[],start=prefix.length?C.simulate(C.initial(c),prefix[0],c):null;
 let found=start&&C.won(start,c)?{solution:[],state:start,expanded:1}:null;
 for(const [width,limit]of [[3,c.lesson?7:45],[8,c.lesson?10:65],[16,80]]){if(found)break;found=solve(c,width,limit,start);}
 if(!found){
  const bombCells=c.board.flatMap((row,r)=>row.flatMap((t,col)=>t&&t.bomb?[r*6+col]:[]));
  for(let attempt=1;attempt<=40&&!found;attempt++){
   c.seed+=100003;const rng=C.seeded(c.seed);
   do{c.board=Array.from({length:6},()=>Array.from({length:6},()=>Math.floor(rng()*5)));}while(C.match(c.board,c).ids.length);
   for(const i of bombCells)c.board[Math.floor(i/6)][i%6]={color:c.board[Math.floor(i/6)][i%6],bomb:true};
   found=solve(c,8,80);c.boardRebuiltForSnake=true;
  }
 }
 if(!found)throw Error('Unsolved '+c.id);
 c.solution=prefix.concat(found.solution);c.moves=c.solution.length+(c.lesson?5:c.id%25===0?2:c.id<151?4:3);
 c.proof={...c.proof,steps:c.solution.length,expanded:found.expanded,method:'verified snake-route beam-search witness, not shortest-path proof',collected:found.state.progress};changes.push({id:c.id,moves:c.solution.length});
 console.log(c.id,c.solution.length,'moves',Math.round((Date.now()-started)/1000)+'s');
 fs.writeFileSync('campaign-levels.js','globalThis.SDVIG_LEVELS='+JSON.stringify(levels)+';\n');
}
fs.writeFileSync('campaign-levels.js','globalThis.SDVIG_LEVELS='+JSON.stringify(levels)+';\n');fs.writeFileSync('reports/snake-repaired-levels.json',JSON.stringify({date:new Date().toISOString(),changes,durationMs:Date.now()-started},null,2));console.log('Repaired',changes.length);
