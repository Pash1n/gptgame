/* Offline deterministic campaign builder. Never runs on the player's device. */
const fs=require('node:fs'),path=require('node:path');
const C=require('../campaign-core.js');
const introductions={21:['line','Цветная геометрия'],29:['corner','Поворот за поворотом'],37:['tee','Точка равновесия'],46:['pins','Золотые штифты'],66:['bombs','Опаловый взрыв'],86:['glass','Хрупкий след'],106:['lock','Ключ от рощи'],126:['pair','Связанные орбиты'],146:['tide','Лунный прилив'],166:['runes','Цветные печати'],186:['beacons','Зажги маяки'],206:['compass','Ритм направлений'],226:['singleStep','Точный шаг']};
const modes=['pins','bombs','glass','lock','pair','tide','runes','beacons','compass','singleStep'];
const titles={pins:'Золотые штифты',bombs:'Опаловый взрыв',glass:'Хрупкий след',lock:'Ключ от рощи',pair:'Связанные орбиты',tide:'Лунный прилив',runes:'Цветные печати',beacons:'Зажги маяки',compass:'Ритм направлений',singleStep:'Точный шаг',line:'Цветная геометрия',corner:'Поворот за поворотом',tee:'Точка равновесия'};
function make(id,attempt){
 const rand=C.seeded(id*8917+attempt*100003+13),pick=n=>Math.floor(rand()*n),shuffled=Array.from({length:36},(_,i)=>i).sort(()=>rand()-.5);
 const chapter=Math.floor((id-1)/50),stage=(id-1)%50;
 const c={id,modern:true,authored:false,revision:13,chapter,stage,seed:id*8917+attempt*100003+13,puzzleTitle:'',title:'',rules:['square','line','square',id>=37?'tee':'square',id>=29?'corner':'square'],targets:[],pins:[],pinGoal:false,bombs:false,bombGoal:0,glass:Array(36).fill(0),lockRow:null,key:null,pair:null,tide:null,runes:[],beacons:[],compass:false,singleStep:false,color:null,goal:0};
 let intro=Object.entries(introductions).filter(([start])=>id>=+start).at(-1),focus=intro[1][0],lesson=id===+intro[0];
 if(id>=246){const available=modes;focus=available[(id-246)%available.length];lesson=false;}
 c.lesson=lesson;c.focus=focus;
 const enabled=new Set();if(modes.includes(focus))enabled.add(focus);
 if(id>=246){enabled.add(modes[(id*7+3)%modes.length]);if(id>=301)enabled.add(modes[(id*3+6)%modes.length]);}
 else if(id>+intro[0]+3&&id%3!==0){const old=modes.filter(m=>Object.entries(introductions).some(([n,[f]])=>f===m&&+n<+intro[0]));if(old.length)enabled.add(old[id%old.length]);}
 if(id>=251)enabled.add('beacons');
 c.puzzleTitle=(lesson?'Открытие · ':id%25===0?'Испытание · ':'')+titles[focus];
 if(id<29)c.rules[3]=c.rules[4]='square';
 const targetColors=lesson&&['line','corner','tee'].includes(focus)?[{line:1,corner:4,tee:3}[focus]]:id<46?[pick(5)]:Array.from(new Set([pick(5),pick(5)]));
 c.targets=targetColors.map(color=>({color,count:lesson?C.SHAPES[c.rules[color]].length:id<86?8:id<186?8+4*(id%2):12+Math.floor((id-186)/100)*4}));
 let at=0;
 if(enabled.has('pins')){c.pins=shuffled.slice(at,at+(lesson?1:id>=301?3:2));at+=c.pins.length;c.pinGoal=true;}
 if(enabled.has('bombs')){c.bombs=true;c.bombGoal=lesson?1:id>=351?2:1;}
 if(enabled.has('glass'))for(let k=0;k<(lesson?1:id>=301?4:2);k++)c.glass[shuffled[at++]]=id>=301&&k%2===0?2:1;
 if(enabled.has('lock')){c.lockRow=4;c.key=shuffled.find(i=>Math.floor(i/6)!==4&&!c.pins.includes(i));}
 if(enabled.has('pair'))c.pair={axis:id%2?'x':'y',a:1,b:4,mode:id%4<2?'same':'opposite'};
 if(enabled.has('tide'))c.tide={axis:id%2?'y':'x',index:2,every:id>=351?2:3,direction:id%2?-1:1};
 if(enabled.has('runes'))for(let k=0;k<(lesson?1:id>=351?2:1);k++)c.runes.push({cell:shuffled[at++],color:pick(5),layers:id>=401&&k===0?2:1});
 if(enabled.has('beacons'))c.beacons=Array.from({length:lesson?2:id<251?3:5+Math.floor((id-251)/50)},()=>pick(5));
 c.compass=enabled.has('compass');c.singleStep=enabled.has('singleStep');
 if(lesson&&['pins','bombs','glass','lock','runes'].includes(focus))c.targets=[];
 if(lesson&&focus==='tide'){c.tideGoal=1;c.targets=[{color:0,count:4}];}
 if(lesson&&focus==='pair')c.targets=[{color:0,count:4}];
 if(lesson&&focus==='compass')c.targets=[{color:0,count:8}];
 if(c.singleStep){c.beacons=c.beacons.slice(0,7).map(color=>color%3);c.runes=c.runes.map(r=>({...r,color:r.color%3}));c.targets=c.targets.slice(0,1).map(t=>({...t,color:0,count:Math.min(t.count,12)}));c.pins=c.pins.slice(0,2);const glass=c.glass.map((v,i)=>v?i:-1).filter(i=>i>=0);c.glass=c.glass.map((v,i)=>glass.slice(0,2).includes(i)?1:0);c.runes=c.runes.map(r=>({...r,layers:1}));c.bombGoal=Math.min(c.bombGoal,1);}
 // A stable board; starting bombs are an explicit resource, never a random rescue.
 do{c.board=Array.from({length:6},()=>Array.from({length:6},()=>pick(5)));}while(C.match(c.board,c).ids.length);
 if(c.bombs){for(let k=0;k<c.bombGoal;k++){const i=shuffled[35-k];c.board[Math.floor(i/6)][i%6]={color:c.board[Math.floor(i/6)][i%6],bomb:true};}}
 c.mechanics=[...enabled];return c;
}
function key(s){return JSON.stringify([s.grid,s.pins,s.terrain,s.progress,s.runes,s.locked,s.beacon,s.turn%6,s.routeSide,s.detourUses,s.portalUses,s.switchCount,s.rngState]);}
function score(s,c){let v=C.heuristic(s,c);const flat=s.grid.flat();
 const needs=[...s.pins.map(cell=>({cell})),...(s.locked?[{cell:c.key}]:[]),...((c.switchGoal||0)>(s.switchCount||0)?[{cell:c.switcher}]:[]),...s.runes.filter(r=>r.layers).map(r=>({cell:r.cell,color:r.color}))];
 for(const n of needs){let best=0;for(let color=0;color<5;color++){if(n.color!=null&&n.color!==color)continue;for(const cells of C.placements[c.rules[color]]){if(!cells.includes(n.cell))continue;let count=0;for(const i of cells)if(flat[i].color===color)count++;best=Math.max(best,count/cells.length)}}v+=best*7;}
 return v;
}
function solve(c,width=3,limit=34,startState=null){let beam=[{s:startState||C.initial(c),path:[],value:0}],seen=new Map(),expanded=0;
 for(let depth=0;depth<limit;depth++){
 const out=[];
 for(const node of beam)for(const move of C.actions(node.s,c)){
 const s=C.simulate(node.s,move,c);expanded++;
 if(C.won(s,c))return{solution:[...node.path,move],state:s,expanded};
 const k=key(s);if((seen.get(k)??Infinity)<=depth)continue;seen.set(k,depth);
 out.push({s,path:[...node.path,move],value:score(s,c)});
 }
 out.sort((a,b)=>b.value-a.value);beam=out.slice(0,width);if(!beam.length)break;
 }
 return null;
}
if(require.main!==module){module.exports={make,solve};return;}
const max=Number(process.env.MAX_LEVEL||500),levels=[],started=Date.now();
if(process.env.RESUME){require('../campaign-levels.js');levels.push(...globalThis.SDVIG_LEVELS);}
for(let id=levels.length?levels.at(-1).id+1:21;id<=max;id++){
 let found=null,c;
 for(let attempt=0;attempt<50&&!found;attempt++){c=make(id,attempt);found=solve(c,attempt<3?3:8,id<46?10:attempt<3?Math.min(38,18+Math.floor(id/30)):64);}
 if(!found)throw Error('No solution for '+id);
 c.solution=found.solution;
 // Teaching levels have more breathing room; trials have a tighter, still proven budget.
 c.moves=c.solution.length+(c.lesson?5:id%25===0?2:id<151?4:3);
 c.proof={steps:c.solution.length,expanded:found.expanded,beacons:c.beacons.length,minimumTurns:c.beacons.length,method:'deterministic beam search; constructive witness, not optimality proof',collected:found.state.progress};
 levels.push(c);
 if(id%10===0)console.log(`${id}: ${c.solution.length} moves, ${Math.round((Date.now()-started)/1000)}s`);
 if(id%25===0)fs.writeFileSync(path.join(__dirname,'../campaign-levels.js'),'globalThis.SDVIG_LEVELS='+JSON.stringify(levels)+';\n');
}
fs.writeFileSync(path.join(__dirname,'../campaign-levels.js'),'globalThis.SDVIG_LEVELS='+JSON.stringify(levels)+';\n');
console.log('Generated',levels.length,'levels in',Math.round((Date.now()-started)/1000),'seconds');
